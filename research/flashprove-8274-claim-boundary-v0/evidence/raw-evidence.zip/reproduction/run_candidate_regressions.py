import os,json,subprocess,sys
from pathlib import Path
W=Path(__file__).resolve().parent
R=W/'veca'; O=R/'build/flashprove-8274/existing-regressions'; O.mkdir(parents=True,exist_ok=True)
commands=[['python','-B','tools/v3/prepare.py','--online'],['python','-B','evidence/erc8404/core/conformance/rvr-v0/adapter.py','--check'],['bun','evidence/erc8404/core/conformance/rvr-v0/adapter.ts','--check'],['python','-B','tools/erc8404/integrity.py'],['python','-B','tools/integration/integrity.py']]
for name,path in [('harness','conformance/agent-harness-v0/erc8404'),('erc8004','conformance/erc8004-pilot-v0'),('v1','conformance/erc8004-role-policy-v1'),('v2','conformance/erc8004-role-policy-v2')]:
 commands.append(['python','-B','tools/agent_harness.py','run','--suite',path+'/suite.json','--adapter',path+'/adapter.json','--out',str(O/name)])
for group in ['harness_v0','erc8004','erc8004_role_policy','erc8004_role_policy_v2','baseline_reconciliation']:
 for mode in [[],['-O']]: commands.append(['python','-B',*mode,'-m','unittest','discover','-s','tests/'+group,'-v'])
rows=[]
for i,c in enumerate(commands):
 p=subprocess.run(c,cwd=R,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'},timeout=900)
 (O/f'{i:02}.stdout').write_bytes(p.stdout);(O/f'{i:02}.stderr').write_bytes(p.stderr)
 rows.append({'command':c,'exit_code':p.returncode});(O/'commands.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(i,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
