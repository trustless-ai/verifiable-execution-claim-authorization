import datetime,hashlib,json,os,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent;repo=ROOT/'baseline';out=ROOT/'baseline-logs';out.mkdir(exist_ok=False)
commands=[['python','-B','tools/verify_artifacts.py'],['python','-B','tools/v3/prepare.py','--online'],
 ['python','-B','tools/agent_harness.py','prepare'],['python','-B','tools/erc8004/prepare.py'],
 ['python','-B','tools/erc8404/validate.py','--out','build/flashprove-baseline/core'],
 ['bun','evidence/erc8404/core/conformance/rvr-v0/adapter.ts','--check'],
 ['python','-B','tools/harness_v0/validate.py','--out','build/flashprove-baseline/harness'],
 ['python','-B','tools/erc8004/validate.py','--out','build/flashprove-baseline/erc8004'],
 ['python','-B','tools/erc8004_role_policy/validate.py','--out','build/flashprove-baseline/v1'],
 ['python','-B','tools/erc8004_role_policy_v2/validate.py','--out','build/flashprove-baseline/v2'],
 ['python','-B','-m','unittest','discover','-s','tests/baseline_reconciliation','-v'],
 ['python','-B','-O','-m','unittest','discover','-s','tests/baseline_reconciliation','-v'],
 ['python','-B','tools/verify_artifacts.py']]
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');rows=[]
for i,cmd in enumerate(commands):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True)
 for k in ('stdout','stderr'):(out/f'{i:02}.{k}').write_bytes(getattr(p,k))
 rows.append({'argv':cmd,'exit':p.returncode,'started_utc':start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
 (out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8',newline='\n');print(i,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
