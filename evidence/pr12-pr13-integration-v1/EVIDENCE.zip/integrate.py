import importlib.util,json,subprocess
from pathlib import Path
def module(name):
 s=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
r=module('run');a=module('core_audit');root=r.ROOT/'integration'
MAIN='999e7047df15585f8ce0629081a1369a4942353f';P12='6e8fabee9be170245f557a271b6d315176cc4a03';P13='c0d3862a590b62a059c1a923ab93b380d609876f';BASE='80c91a09095eca362dbfb69d39d0c01fc31130cf'
def data(ref):return json.loads(subprocess.check_output(['git','show',ref+':artifacts.sha256.json'],cwd=root))
for label,old,new in [('pr12',BASE,P12),('pr13',P12,P13)]:
    current=json.loads((root/'artifacts.sha256.json').read_bytes());previous=data(old)['files'];incoming=data(new)['files']
    additions={p:d for p,d in incoming.items() if p not in previous}
    if any(incoming.get(p)!=d for p,d in previous.items()):raise ValueError('Not additive historical PR')
    if set(additions)&set(current['files']):raise ValueError('Unexpected repeated import')
    r.run('merge-'+label,['git','merge','--no-ff','--no-commit',new],root,allow=True)
    unmerged=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root).decode().splitlines()
    r.run('conflicts-'+label,['git','ls-files','-u'],root)
    if unmerged!=['artifacts.sha256.json']:raise ValueError('Unexpected conflicts '+repr(unmerged))
    current['files'].update(additions)
    (root/'artifacts.sha256.json').write_text(json.dumps(current,sort_keys=True,indent=2)+'\n',encoding='utf-8',newline='\n')
    r.run('resolve-'+label,['git','add','artifacts.sha256.json'],root)
    r.run('core-integrity-after-'+label,[r.PY,'-B','tools/erc8404/integrity.py'],root)
    a.audit(root,'after-'+label)
    r.run('inventory-after-'+label,[r.PY,'-B','tools/verify_artifacts.py'],root)
    r.run('commit-'+label,['git','commit','-m','Integrate '+label.upper()+' provenance on current main; preserve exact inventory union'],root)
    r.save(r.ROOT/('integration-'+label+'.json'),{'source':new,'source_base':old,'added_files':additions,'conflicts':unmerged,'resolution':'Union of disjoint PR additions and exact current-main entries; no historical entries resealed.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()})
