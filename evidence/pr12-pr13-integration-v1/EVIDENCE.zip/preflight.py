from pathlib import Path
import importlib.util,json,subprocess
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner',ROOT/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
G=ROOT/'git-store';URL='https://github.com/trustless-ai/verifiable-execution-claim-authorization.git'
MAIN='999e7047df15585f8ce0629081a1369a4942353f';P12='6e8fabee9be170245f557a271b6d315176cc4a03';P13='c0d3862a590b62a059c1a923ab93b380d609876f'
def git(*args):return subprocess.check_output(['git','-C',str(G),*args]).decode().strip()
r.run('preflight-origin',['git','remote','set-url','origin',URL],G)
r.run('preflight-fetch',['git','fetch','origin','+refs/heads/*:refs/remotes/origin/*','+refs/pull/12/head:refs/remotes/origin/pr12-head','+refs/pull/13/head:refs/remotes/origin/pr13-head','--tags'],G)
if git('rev-parse','--is-shallow-repository')!='false':raise RuntimeError('Full history required')
for ref,expected in [('refs/remotes/origin/main',MAIN),('refs/remotes/origin/pr12-head',P12),('refs/remotes/origin/pr13-head',P13)]:
    if git('rev-parse',ref)!=expected:raise RuntimeError('Unexpected moved ref: '+ref)
for number in (12,13):r.run('preflight-pr'+str(number),['gh','pr','view',str(number),'--repo','trustless-ai/verifiable-execution-claim-authorization','--json','number,title,state,isDraft,baseRefName,baseRefOid,headRefName,headRefOid,body,url,updatedAt'],ROOT)
branch='review/veca-pr12-pr13-integration-v1'
if git('branch','--list',branch):raise RuntimeError('Integration branch already exists; inspect it')
r.run('worktree-integration',['git','worktree','add','-b',branch,str(ROOT/'integration'),MAIN],G)
for label,pin in [('baseline-main',MAIN),('baseline-pr12',P12),('baseline-pr13',P13)]:r.run('worktree-'+label,['git','worktree','add','--detach',str(ROOT/label),pin],G)
result={'origin':URL,'main':MAIN,'pr12':P12,'pr13':P13,'branch':branch,'full_history':True,'pr12_base':git('merge-base',MAIN,P12),'pr13_base':git('merge-base',P12,P13),'pr12_diff':git('diff','--name-status','80c91a09095eca362dbfb69d39d0c01fc31130cf',P12),'pr13_diff':git('diff','--name-status',P12,P13),'main_vs_pr12_base':git('diff','--stat','80c91a09095eca362dbfb69d39d0c01fc31130cf',MAIN),'dag':git('log','--graph','--oneline','--all','-55')}
r.save(ROOT/'PREFLIGHT.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['dag','main_vs_pr12_base','pr12_diff','pr13_diff']},indent=2))
