"""Bind executed runtime/compiler/code hashes to each physical mutant's bytes."""
from pathlib import Path
import hashlib,json,sys
def sha(b):return hashlib.sha256(b).hexdigest()
def require(c,m):
 if not c:raise ValueError(m)
def read(p):return json.loads(p.read_bytes())
def runtime(folder):
 data=read(folder/'adapter.stdout')['observations'];values=[r['evidence']['runtime'] for r in data.values()]
 require(values and all(v==values[0] for v in values),'runtime inconsistency')
 return values[0]
def audit(folder):
 folder=Path(folder);summary=read(folder/'report.json');rows=[]
 require(summary['counts']=={'KILLED':6} and summary['original_source_unchanged'],'campaign not complete')
 for record in summary['results']:
  case=folder/record['id'];original=runtime(case/'baseline');mutated=runtime(case/'mutated');old=runtime(case/'original-matrix');restored=runtime(case/'restored')
  path=record['source'];source=sha((case/'mutated-source.sol').read_bytes())
  require(source==record['mutant_sha256']==mutated['source_sha256'][path]==old['source_sha256'][path],'executed mutant hash mismatch')
  require(original['source_sha256'][path]==record['original_sha256']==restored['source_sha256'][path],'original or restored bytes mismatch')
  require(source!=record['original_sha256'],'not a physical mutant')
  require(original['compiler_input_sha256']!=mutated['compiler_input_sha256']==old['compiler_input_sha256'],'compiler input did not change')
  key='identity_codehash' if 'IdentityRegistry' in path else 'validation_codehash'
  require(original[key]!=mutated[key]==old[key],'actual EVM code did not change')
  require(original[key]==restored[key] and original['compiler_input_sha256']==restored['compiler_input_sha256'],'backend restoration mismatch')
  shrink=read(case/'shrink/result.json');last=shrink['attempts'][-1]
  final_folder=(case/'shrink'/last['report']).parent
  final=runtime(final_folder)
  require(final['source_sha256'][path]==source and final[key]==mutated[key],'minimized witness executed another backend')
  original_matrix=read(case/'original-matrix/report.json')
  require(original_matrix['exit_code']==0 and len(original_matrix['rows'])==29,'original matrix did not miss this mutant')
  rows.append({'id':record['id'],'source':path,'source_before':record['original_sha256'],'source_mutant':source,
   'compiler_before':original['compiler_input_sha256'],'compiler_mutant':mutated['compiler_input_sha256'],
   'deployed_code_before':original[key],'deployed_code_mutant':mutated[key],
   'original_matrix_conformant':29,'generated_classification':record['classification'],
   'positive_controls':record['positive_count'],'witness_id':record['witness_id'],'divergence':record['divergence'],
   'minimized_sequence':shrink['minimized']['sequence'],'minimized_calls':shrink['minimized_calls'],
   'deletion_1_minimal':shrink['deletion_1_minimal'],'global_minimum_claimed':shrink['global_minimum_claimed'],
   'backend_restored':True})
 return {'schema':'physical-mutant-runtime-binding-audit-v1','passed':True,'campaign':str(folder),'results':rows}
if __name__=='__main__':
 result=audit(sys.argv[1]);out=Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
 out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps({'passed':True,'mutants':len(result['results'])}))
