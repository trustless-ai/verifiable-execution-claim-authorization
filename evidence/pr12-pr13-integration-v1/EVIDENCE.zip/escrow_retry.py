"""Use the frozen Foundry-permitted evidence directory; never widen permissions."""
from pathlib import Path
import json,os,subprocess,time
import run as r
import core_audit

ROOT=Path(__file__).resolve().parent
repo=ROOT/'fresh'
os.environ['PATH']='C:/Users/msi/.foundry/bin;C:/Users/msi/.bun/bin;'+os.environ['PATH']
os.environ['FORGE']='C:/Users/msi/.foundry/bin/forge.exe'
deadline=time.monotonic()+7200
print('Waiting for serial and post-replay work; no concurrent mutations.',flush=True)
while not (ROOT/'POST_REPLAY_DONE.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('Prior replay did not finish')
    time.sleep(5)
if subprocess.check_output(['git','status','--porcelain'],cwd=repo):raise RuntimeError('Source is not restored before retry')
failed=json.loads((ROOT/'logs/fresh-final-escrow.json').read_bytes())
if failed['exit_code']!=1:raise RuntimeError('Unexpected first-attempt result')
raw=(repo/'build/final/escrow/validation/evm-normal.stdout.log').read_text(encoding='utf-8')
if 'is not allowed to be accessed for write operations' not in raw:raise RuntimeError('Different failure requires diagnosis')
r.run('fresh-final-escrow-r2',[r.PY,'-B','tools/escrow_ci.py','--out','build/escrow/ci-integration-v1'],repo)
for name,args in [('core',['tools/erc8404/integrity.py']),('preservation',['tools/pr12_pr13_integration/preservation.py','--fuzz']),('inventory',['tools/verify_artifacts.py'])]:
    r.run('escrow-r2-final-'+name,[r.PY,'-B',*args],repo)
core_audit.audit(repo,'fresh-after-escrow-r2')
r.run('escrow-r2-final-status',['git','status','--porcelain=v1'],repo)
r.run('escrow-r2-final-diff-check',['git','diff','--check'],repo)
if (ROOT/'logs/escrow-r2-final-status.stdout').read_bytes():raise RuntimeError('Source not restored after escrow')
r.save(ROOT/'ESCROW_RETRY_DONE.json',{'passed':True,'source_or_config_changed':False,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'reason':'First output path was outside frozen Foundry fs_permissions; retry uses existing permitted build/escrow subtree.','successful_output':'fresh/build/escrow/ci-integration-v1'})
