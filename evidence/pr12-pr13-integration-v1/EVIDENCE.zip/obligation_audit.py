"""Audit locators and non-promotion populations without updating historical claims."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
repo=ROOT/'integration'
report=json.loads((repo/'build/integration-smoke/coverage/COVERAGE.json').read_bytes())
rows=[]
for profile in report['profiles']:
 for obligation in profile['obligations']:
  rows.append({'profile':profile['id'],'id':obligation['id'],'source_commit':profile['source_commit'],
   'source_ids':obligation['source_ids'],'traceability':obligation['source_pin_and_clause'],
   'level':obligation['highest_supported_level'],'fixture_ids':obligation['fixture_ids'],
   'executed_fixture_ids':obligation['executed_fixture_ids'],'matched_fixture_ids':obligation['matched_fixture_ids'],
   'guards':obligation['physical_mutation_bindings'],'witnesses':obligation['negative_or_distinguishing_witnesses'],
   'positive_controls':obligation['positive_controls'],'independent_replay':obligation['independent_replay']})
assert len(rows)==51
assert sum(bool(r['guards']) for r in rows)==39
assert sum(r['level']=='EXECUTED_AND_MATCHED' for r in rows)==12
assert all(r['traceability'] and r['fixture_ids'] and r['executed_fixture_ids'] for r in rows)
assert report['new_backend_execution'] is False and report['independent_replay']=='NOT_COVERED'
summary={'schema':'veca-51-obligation-locator-audit-v1','passed':True,'executor':'OpenAI Codex, same local machine; no independent organizational review',
 'coverage_input_sha256':hashlib.sha256((repo/'build/integration-smoke/coverage/COVERAGE.json').read_bytes()).hexdigest(),
 'obligations':rows,'obligation_count':len(rows),'guard_mapped':39,'executed_only':12,
 'case_populations':{p['id']:p['matched_count'] for p in report['profiles']},
 'mutation_populations':{p['id']:p['counts'] for p in report['mutation_populations']},
 'limits':['Automated locator and evidence-bound reconciliation plus source inspection; no independently reviewed normative interpretation.',
           'Historical catalog scope stays unchanged; current main role-policy v1/v2 are tested separately, not backfilled into the historical 51.',
           'New actual PR12 execution is reported separately from the historical reports read by PR13.']}
(ROOT/'OBLIGATION_AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('obligations','limits')},indent=2))
