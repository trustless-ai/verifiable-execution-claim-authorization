import importlib.util,subprocess,json
from pathlib import Path
s=importlib.util.spec_from_file_location('r',Path(__file__).with_name('run.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
root=r.ROOT/'integration'
r.run('candidate-preservation',[r.PY,'-B','tools/pr12_pr13_integration/preservation.py'],root)
r.run('candidate-stage',['git','add','artifacts.sha256.json','.github/workflows/erc8004-property-fuzz.yml','.github/workflows/spec-drift-coverage.yml','tools/pr12_pr13_integration','research/pr12-pr13-integration-v1','evidence/pr12-pr13-integration-v1'],root)
r.run('candidate-diff-check',['git','diff','--cached','--check'],root)
r.run('candidate-commit',['git','commit','-m','Add exact PR12/PR13 preservation transition and external integration replay'],root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root).decode().strip()
r.save(r.ROOT/'CANDIDATE.json',{'head':head,'tree':tree,'branch':'review/veca-pr12-pr13-integration-v1','state':'REPLAY_PENDING'})
r.run('fresh-worktree',['git','worktree','add','--detach',r.ROOT/'fresh',head],r.ROOT/'git-store')
r.run('fresh-status',['git','status','--porcelain=v1'],r.ROOT/'fresh')
print(head,tree)
