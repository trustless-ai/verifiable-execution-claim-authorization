"""Publish only local, new report/evidence after all required actual replay gates pass."""
from pathlib import Path
import hashlib,json,re
import package_review as pack
ROOT=Path(__file__).resolve().parent
TARGET=ROOT/'integration'
EVIDENCE=TARGET/'evidence/pr12-pr13-integration-v1'
def read(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
def text(path,value):path.write_text(value,encoding='utf-8',newline='\n')
def short_counts(value):return ', '.join(str(n)+' '+k for k,n in value.items() if n)

def main():
 index=read(ROOT/'EXECUTION_INDEX.json');require(index['passed'],'execution index not passing')
 comparison=read(ROOT/'REPLAY_COMPARISON.json');require(comparison['passed'],'behavioral comparison not passing')
 require(read(ROOT/'REMOTE_CLOSURE.json')['matches_preflight_source_refs'],'remote refs moved')
 core=read(ROOT/'core-audits/fresh-after-escrow-r2.json');require(core['passed'],'Core audit missing')
 runtime=read(ROOT/'fresh/build/final/core-binding/RESULTS.json');require(runtime['passed'] and runtime['observation_matches_native_bytes'],'runtime binding failed')
 sources={
  'fuzz':'fuzz/summary.json','spec':'spec/SUMMARY.json','legacy':'fuzz/legacy/summary.json',
  'harness':'harness/summary.json','supplement':'supplement/summary.json',
  'role-v1':'role-v1/summary.json','role-v2':'role-v2/summary.json',
  'core-consumer':'core-consumer/report.json','v0':'v0/report.json','formal-v1':'formal-v1/report.json',
  'v2':'v2/report.json','v2-survivors':'v2-survivors/report.json','v3':'v3/report.json',
  'v4':'v4/report.json','claim-integration':'claim-integration/report.json',
  'v0-python313':'v0-python313/report.json',
 }
 suites={name:read(ROOT/'fresh/build/final'/path) for name,path in sources.items()}
 suites['escrow']=read(ROOT/'fresh/build/escrow/ci-integration-v1/report.json')
 require(all(s['passed'] is True for s in suites.values()),'one suite is not passing')
 preserved={mode:read(ROOT/'fresh/build/final'/('preservation-'+mode)/'RESULTS.json') for mode in ('normal','repeat','optimized')}
 require(all(p['passed'] and len(p['cases'])==6 for p in preserved.values()),'preservation controls incomplete')
 preservation='All six attacks are REJECTED in normal/repeat/-O, with passing positive and restoration controls in every mode.'
 rows=[
  ['Pinned PR12 baseline','300/300 per normal/repeat/-O; 6/6 physical mutants KILLED in normal and -O; original 29 misses all six.'],
  ['Pinned PR13 baseline','Original 32 controls and 13 transport controls in normal/-O; offline normal/repeat/-O bytes identical.'],
  ['Pinned main baseline','29/29 ERC8004, 17/17 mutations; 18/18 Core harness, 12/12 consumer mutations; behavioral repeats pass.'],
  ['Candidate generated profile','300/300 per normal/repeat/-O; 6/6 Solidity mutants KILLED in normal and -O; source/backend restoration passes.'],
  ['Candidate spec/drift','32 integrated controls (31 original + 1 versioned preservation) and 13 transport controls in all three modes; 51 obligations audited.'],
  ['Candidate original ERC8004 pilot',str(suites['legacy']['conformant'])+'/'+str(suites['legacy']['scenarios'])+'; '+short_counts(suites['legacy']['mutations'])+'; extra optimized mutation campaign passes.'],
  ['Candidate original 18-case harness',str(suites['harness']['conformant_scenarios'])+'/'+str(suites['harness']['scenario_count'])+'; '+short_counts(suites['harness']['mutations'])+'; extra optimized mutations pass.'],
  ['PR11 supplement',str(suites['supplement']['scenario_count'])+' cases; isolated '+short_counts(suites['supplement']['isolated_mutation_counts'])+'; original-matrix probe separately '+short_counts(suites['supplement']['reviewer_experiment_counts'])+'.'],
  ['Role policy v1',str(suites['role-v1']['conformant'])+'/'+str(suites['role-v1']['cases'])+' cases; controls '+str(suites['role-v1']['controls'])+'; '+short_counts(suites['role-v1']['physical_mutations'])+'.'],
  ['Role policy v2',str(suites['role-v2']['conformant'])+'/'+str(suites['role-v2']['cases'])+' cases; controls '+str(suites['role-v2']['controls'])+'; '+short_counts(suites['role-v2']['physical_mutations'])+'.'],
  ['External ERC8404 consumer',str(suites['core-consumer']['scenarios'])+' scenarios; '+short_counts(suites['core-consumer']['mutations'])+'; historical survivor remains classified separately; all three semantic repeats agree.'],
 ]
 for name in ('v0','formal-v1','v2','v2-survivors','v3','v4','claim-integration','escrow','v0-python313'):
  s=suites[name];detail='PASS'
  for key in ('scenarios','escrow_scenarios'):
   if key in s:detail+='; '+str(s[key])+' scenarios'
  for key in ('mutations','counts','new_mutations'):
   if key in s:detail+='; '+short_counts(s[key])
  if name=='escrow':detail+='; '+str(len(s['negative_controls']['controls']))+' negative CI controls'
  rows.append([name,detail+'; complete raw validator report retained.'])
 v41=read(ROOT/'logs/fresh-final-v4_1-run.stdout')
 v41mut=read(ROOT/'fresh/build/final/v4_1-mutations/report.json')
 rows.append(['v4.1',str(len(v41['cases']))+' cases / '+str(len(v41['reuse']))+' reuse checks; '+short_counts(v41mut['counts'])+'; normal/-O tests and mutations pass.'])
 rows.append(['Preservation transition',preservation])
 table='| Execution population | Newly observed result |\n| --- | --- |\n'+'\n'.join('| '+name+' | '+detail.replace('|','/')+' |' for name,detail in rows)
 v3_limits=read(ROOT/'fresh/build/final/v3/mutations-normal/report.json')['unexecuted_integration_boundaries']
 v4_limits=read(ROOT/'fresh/build/final/v4/mutations-normal/report.json')['uncovered']
 uncovered={'v3':{'status':'NOT_COVERED','boundaries':v3_limits},
            'v4':{'status':'NOT_COVERED','boundaries':v4_limits},
            'public_chain_authentication':'NOT_COVERED',
            'all_defensive_parser_branches':'NOT_COVERED; integration mutation scope remains finite'}
 archive=pack.package()
 remaining=('No unresolved integration defect was observed in the required executed checks. '
  'All '+str(index['workflow_count'])+' repository workflow families have local command coverage; hosted GitHub Actions on this new branch is NOT_RUN because no push was authorized. '
  'Windows local success does not establish Ubuntu-hosted CI success. Independent human/organizational review and a same-profile independent implementation remain NOT_ESTABLISHED/NOT_COVERED.\n\n'
  'Published finite-coverage limits remain visible: the old external Core-consumer mutation campaign retains its survivor; '
  'the original v2 campaign retains 18 KILLED / 2 SURVIVED / 1 UNVERIFIABLE, separately from the two later survivor controls; '
  'the PR11 original-matrix probe remains 1 KILLED / 4 SURVIVED, separately from its 4 KILLED isolated controls; '
  'escrow retains 6 NOT_APPLIED absent on-chain checks. These denominators are not merged or relabelled. '
  'Existing laboratory escrow checks were replayed without real funds or a new end-to-end pilot. '
  'The candidate is ready for an independent reviewer to inspect and replay; production remains HOLD.\n\n'
  'Inherited NOT_COVERED v3 boundaries: '+', '.join('`'+n+'`' for n in v3_limits)+'. '
  'Inherited v4 uncovered scope: '+', '.join('`'+n+'`' for n in v4_limits)+'. '
  'Public-chain authentication and exhaustive coverage of every defensive parser branch are not established. '
  'These are retained domain/coverage limits, separate from the successfully executed required integration checks.')
 result={'schema':'veca-pr12-pr13-integration-results-v1','verdict':'READY_FOR_INDEPENDENT_REVIEW',
  'ERC8404_CORE_UNCHANGED':'PASS','production':'HOLD','executed_source_commit':pack.CANDIDATE,
  'executed_source_tree':'9960cb23dd78b0202ae5c370f8713eb76b35e413',
  'branch':'review/veca-pr12-pr13-integration-v1','newly_executed_summaries':suites,
  'table':rows,'preservation_controls':preserved,'core_runtime_binding':runtime,
  'protected_core_related_files':len(core['protected_files']),'upstream_core_files':len(core['upstream_files']),
  'vendored_core_files':core['vendored_files'],'archive_sha256':archive['archive_sha256'],
  'archive_members':archive['member_count'],'workflow_count':index['workflow_count'],
  'unverified_boundaries':uncovered,
  'hosted_candidate_ci':'NOT_RUN','independent_human_review':'NOT_ESTABLISHED',
  'historical_evidence_rewritten':False,'remote_writes_performed':False,
  'final_commit_identity':'See local FINAL_CLOSURE.json and git rev-parse HEAD; report/evidence-only closure follows executed source candidate.'}
 save(EVIDENCE/'RESULTS.json',result)
 template=(ROOT/'report_template.md').read_text(encoding='utf-8')
 values={'VERDICT':result['verdict'],'CORE':'PASS','PRESERVATION_RESULTS':preservation,'RESULT_TABLE':table,
  'REPLAY_COMPARISON':'The new candidate and pinned baselines also match byte-for-byte for the original 29-case and 18-case behavioral projections. All four executed physical mutation campaigns (baseline/candidate, normal/-O) have identical semantic witness, source, compiler and deployed-code audit records. See REPLAY_COMPARISON.json.',
  'ADDITIONAL_FAILURES':'No additional unresolved execution failure remains. Raw failed setup/smoke attempts are retained separately from successful corrected runs in EXECUTION_INDEX.json.',
  'ARCHIVE_SHA':archive['archive_sha256'],'REMAINING':remaining}
 for key,value in values.items():template=template.replace('@@'+key+'@@',value)
 require('@@' not in template,'unresolved report template field')
 text(TARGET/'research/pr12-pr13-integration-v1/REPORT.md',template)
 text(EVIDENCE/'README.md','# New PR12/PR13 integration evidence\n\n'
  'This directory records newly executed integration replays, their pinned inputs and a new report. Historical captures used by offline replay retain their original observation times; reading them is not a new backend execution. Original research evidence is unchanged.\n\n'
  'Executed source candidate: `'+pack.CANDIDATE+'`. Production HOLD. Independent human review is NOT_ESTABLISHED.\n\n'
  '`RESULTS.json` records actual suite results and scope. `EVIDENCE.zip` contains '+str(archive['member_count'])+' evidence members, including exact commands, outputs, fixtures, mutation descriptions and backend witnesses, restoration results, source pins and Git-object audits. '
  'Complete source snapshots and generated compiler caches are excluded from the committed archive; ARCHIVE_OMISSIONS.json binds their exact task-workspace paths and hashes. No complete mutated source copy is imported into the candidate. '
  '`SHA256.json` binds every member and these new closure artifacts.\n\n'
  'Archive SHA-256: `'+archive['archive_sha256']+'`.\n\n'
  'Read [the integration report](../../research/pr12-pr13-integration-v1/REPORT.md) and [replay instructions](../../research/pr12-pr13-integration-v1/README.md). '
  'Archive integrity is not an execution or independence attestation. The final local commit and tree are recorded in the task workspace FINAL_CLOSURE.json; source/config/fixture equality to the executed candidate is separately checked.\n')
 outer={p:sha((TARGET/p).read_bytes()) for p in sorted(pack.ALLOWED) if p not in {'artifacts.sha256.json','evidence/pr12-pr13-integration-v1/SHA256.json'}}
 save(EVIDENCE/'SHA256.json',{'schema':'veca-integration-evidence-sha256-v1','files':outer,'archive_members':archive['members'],
  'exclusions':['this manifest itself; pinned by repository artifact inventory'],'historical_manifests_changed':False})
 manifest=read(TARGET/'artifacts.sha256.json');before=dict(manifest['files'])
 for path in pack.ALLOWED-{'artifacts.sha256.json'}:manifest['files'][path]=sha((TARGET/path).read_bytes())
 require(all(manifest['files'][p]==d for p,d in before.items() if p not in pack.ALLOWED),'historical entry changed')
 text(TARGET/'artifacts.sha256.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 pack.source_closure('SOURCE_CLOSURE_AFTER_REPORT.json')
 print(json.dumps({'verdict':result['verdict'],'core':'PASS','archive_sha256':archive['archive_sha256'],'members':archive['member_count']}))

if __name__=='__main__':main()
