"""Require completed executions and retain failed attempts separately."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_bytes())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')

def main():
 require((ROOT/'POST_REPLAY_DONE.json').is_file(),'replay incomplete')
 require(read(ROOT/'ESCROW_RETRY_DONE.json')['passed'],'escrow retry incomplete')
 receipts={p.stem:read(p) for p in sorted((ROOT/'logs').glob('*.json'))}
 failures={k:v for k,v in receipts.items() if v.get('exit_code')!=0}
 resolved={
  'merge-pr12':'Expected inventory merge conflict; exact disjoint union in resolve-pr12 / commit-pr12.',
  'merge-pr13':'Expected inventory merge conflict; exact disjoint union in resolve-pr13 / commit-pr13.',
  'smoke-preservation-normal':'Precommit Windows path-length setup failure; corrected new control temp path; smoke-preservation-normal-r2 and final three modes.',
  'integration-smoke-spec':'Precommit edited-new-file inventory mismatch; frozen clean candidate fresh-spec fully passed.',
  'fresh-escrow-prepare':'LF checkout differs from historical CRLF dependency lock; separate exact workflow clone; fresh-escrow-prepare-r2.',
  'fresh-final-escrow':'Initial output outside frozen Foundry fs_permissions; fresh-final-escrow-r2 uses existing permitted build/escrow subtree without source/config changes.',
 }
 require(set(failures)<=set(resolved),'Unresolved failed execution receipts: '+repr(set(failures)-set(resolved)))
 required=['baseline-pr12-validate','baseline-pr13-validate','baseline-main-pilot','baseline-main-harness',
  'baseline-pr12-mutations-optimized','fresh-spec','fresh-live-drift','fresh-runtime',
  'fresh-native-prepare','fresh-escrow-prepare-r2','fresh-final-v0-python313',
  'backend-audit-baseline-pr12-optimized','backend-audit-candidate-normal','backend-audit-candidate-optimized',
  'final-core-integrity','final-artifact-integrity','final-source-status']
 required+=['fresh-final-'+('escrow-r2' if name=='escrow' else name) for name in read(ROOT/'FINAL_SERIAL_DONE.json')['plan_labels']]
 required+=['escrow-r2-final-'+name for name in ('core','preservation','inventory','status','diff-check')]
 required+=['fresh-final-preservation-'+mode for mode in ('normal','repeat','optimized')]
 for name in required:require(name in receipts and receipts[name]['exit_code']==0,'required gate absent or failed: '+name)
 for name in ('fresh-status','fresh-semantics-status','fresh-final-status','final-source-status','escrow-r2-final-status'):
  require((ROOT/'logs'/(name+'.stdout')).read_bytes()==b'','dirty checkout: '+name)
 for name,row in receipts.items():
  for stream in ('stdout','stderr'):
   require(hashlib.sha256((ROOT/'logs'/(name+'.'+stream)).read_bytes()).hexdigest()==row[stream+'_sha256'],'command stream changed: '+name)
 wf={
  'reproduce.yml':['fresh-final-v0','fresh-final-v0-python313'],
  'formal-v1.yml':['fresh-final-formal-v1'],
  'real-artifact-v2.yml':['fresh-final-v2-statement','fresh-final-v2','fresh-final-v2-snapshot','fresh-final-v2-survivors'],
  'real-chain-v3.yml':['fresh-final-v3'],
  'coverage-v4.yml':['fresh-final-v4'],
  'coverage-v4_1.yml':['fresh-final-v4_1-run','fresh-final-v4_1-tests','fresh-final-v4_1-tests-optimized','fresh-final-v4_1-mutations','fresh-final-v4_1-mutations-optimized'],
  'claim-aware-integration.yml':['fresh-final-claim-integration'],
  'erc8404-compatibility.yml':['fresh-final-core-consumer','fresh-core-typescript-normal','fresh-final-core-benchmark'],
  'verdict-escrow.yml':['fresh-final-escrow-r2'],
  'agent-harness-v0.yml':['fresh-final-harness'],
  'agent-harness-review.yml':['fresh-final-supplement'],
  'erc8004-harness.yml':['fresh-final-fuzz'],
  'erc8004-role-policy-v1.yml':['fresh-final-role-policy-v1'],
  'erc8004-role-policy-v2.yml':['fresh-final-role-policy-v2'],
  'baseline-reconciliation.yml':['fresh-tests-baseline_reconciliation-normal','fresh-tests-baseline_reconciliation-optimized','fresh-final-role-policy-v1'],
  'erc8004-property-fuzz.yml':['fresh-final-fuzz'],
  'spec-drift-coverage.yml':['fresh-spec','fresh-live-drift'],
 }
 actual={p.name for p in (ROOT/'fresh/.github/workflows').glob('*.yml')}
 require(set(wf)==actual,'workflow coverage membership differs')
 for labels in wf.values():
  for name in labels:require(receipts[name]['exit_code']==0,'workflow command failed: '+name)
 units=[]
 for path in sorted((ROOT/'logs').glob('*.stderr')):
  found=re.findall(rb'Ran (\d+) tests',path.read_bytes())
  if found:units.append({'command':path.stem,'test_counts':[int(n) for n in found]})
 result={'schema':'veca-integration-execution-index-v1','passed':True,
  'required_commands':required,'command_count':len(receipts),
  'commands':receipts,'failed_attempts':{name:{'receipt':failures[name],'resolution':resolved[name]} for name in failures},
  'workflow_command_coverage':wf,'workflow_count':len(wf),
  'github_actions_execution':'NOT_RUN: local branch was not pushed; local Windows execution is not hosted Ubuntu CI',
  'unit_test_log_counts':units,'population_summing_permitted':False}
 save(ROOT/'EXECUTION_INDEX.json',result)
 print(json.dumps({'passed':True,'command_receipts':len(receipts),'workflows':len(wf),'retained_failed_attempts':list(failures)}))

if __name__=='__main__':main()
