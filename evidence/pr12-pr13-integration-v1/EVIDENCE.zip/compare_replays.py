"""Compare newly executed pinned baselines and candidate, with explicit projections."""
from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)

def main():
 require((ROOT/'POST_REPLAY_DONE.json').is_file(),'replay not finished')
 rows=[]
 pairs=[
  ('generated-300','baseline-pr12/build/integration-review-baseline/campaign-normal/projection.json','fresh/build/final/fuzz/campaign-normal/projection.json'),
  ('legacy-29','baseline-main/build/integration-review-baseline/normal/projected.json','fresh/build/final/fuzz/legacy/normal/projected.json'),
  ('core-harness-18','baseline-main/build/integration-review-harness/normal/projected.json','fresh/build/final/harness/normal/projected.json'),
 ]
 for label,before,after in pairs:
  left,right=(ROOT/before).read_bytes(),(ROOT/after).read_bytes()
  require(left==right,'baseline/candidate behavioral mismatch: '+label)
  rows.append({'population':label,'baseline':before,'candidate':after,'byte_identical':True,'sha256':sha(left)})
 audits=[read(ROOT/'audits'/n) for n in ['baseline-pr12-mutations.json','baseline-pr12-optimized.json','candidate-normal.json','candidate-optimized.json']]
 # Each audit contains only source, compiler, deployed-code and semantic witness
 # fields. Timing, absolute directories and interpreter-mode labels are excluded.
 require(all(a['passed'] for a in audits),'backend audit failure')
 require(all(a['results']==audits[0]['results'] for a in audits),'physical witness/backend result differs')
 optimization=[]
 locations=[('baseline-optimized',ROOT/'baseline-pr12/build/integration-review-mutations-optimized',True),
            ('candidate-normal',ROOT/'fresh/build/final/fuzz/mutations',False),
            ('candidate-optimized',ROOT/'fresh/build/final/fuzz/mutations-optimized',True)]
 for prefix,base in [('baseline',ROOT/'baseline-pr12/build/integration-review-baseline'),('candidate',ROOT/'fresh/build/final/fuzz')]:
  for mode in ('normal','repeat','optimized'):
   locations.append((prefix+'-campaign-'+mode,base/('campaign-'+mode),mode=='optimized'))
 for label,folder,opt in locations:
  reports=[]
  for path in sorted(folder.rglob('report.json')):
   obj=read(path)
   if 'adapter_argv' not in obj:continue
   argv=obj['adapter_argv']
   require(argv.count('-O')==(1 if opt else 0) and '-OO' not in argv,'child optimization mismatch: '+str(path))
   reports.append({'path':path.relative_to(ROOT).as_posix(),'adapter_argv':argv,'adapter_exit_code':obj['adapter_exit_code']})
  require(bool(reports),'no executed child backend reports')
  optimization.append({'population':label,'optimized':opt,'reports':reports})
 result={'schema':'veca-new-replay-comparison-v1','passed':True,'behavioral_comparisons':rows,
         'four_executed_mutation_campaigns_identical_semantic_backend_audits':True,
         'child_optimization':optimization,
         'independent_human_or_implementation_review':False}
 out=ROOT/'REPLAY_COMPARISON.json'
 require(not out.exists(),'comparison already exists')
 out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps({'passed':True,'baseline_populations':len(rows),'mutation_campaigns':len(audits),'child_reports':sum(len(r['reports']) for r in optimization)}))

if __name__=='__main__':main()
