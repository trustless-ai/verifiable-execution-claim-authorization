"""Verify and commit only the new report/evidence closure; never touch remote refs."""
from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
import run as r
import package_review as pack
import core_audit
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'integration'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()

def main():
 require(git('rev-parse','HEAD')==pack.CANDIDATE,'source candidate changed before closure')
 require(git('branch','--show-current')=='review/veca-pr12-pr13-integration-v1','unexpected branch')
 changed=set(git('diff','--name-only',pack.CANDIDATE).splitlines())
 require(changed==pack.ALLOWED,'unexpected closure delta: '+repr(changed))
 source=pack.source_closure('SOURCE_CLOSURE_PRECOMMIT.json')
 manifest=json.loads((REPO/'evidence/pr12-pr13-integration-v1/SHA256.json').read_bytes())
 for path,digest in manifest['files'].items():require(sha((REPO/path).read_bytes())==digest,'new evidence file identity: '+path)
 archive=REPO/'evidence/pr12-pr13-integration-v1/EVIDENCE.zip'
 with zipfile.ZipFile(archive) as z:
  require(set(z.namelist())==set(manifest['archive_members']),'archive membership')
  require(all(sha(z.read(p))==d for p,d in manifest['archive_members'].items()),'archived member identity')
 added=git('diff','--name-only','--diff-filter=A','999e7047df15585f8ce0629081a1369a4942353f',pack.CANDIDATE).splitlines()
 for path in added:
  if path.startswith(('tools/pr12_pr13_integration/','research/pr12-pr13-integration-v1/','evidence/pr12-pr13-integration-v1/')) and not path.endswith('.zip'):
   require(b'\r' not in (REPO/path).read_bytes(),'new technical text is not LF-only: '+path)
 r.run('closure-diff-check',['git','diff','--check'],REPO)
 for name,args in [('core',['tools/erc8404/integrity.py']),('preservation',['tools/pr12_pr13_integration/preservation.py','--fuzz']),('inventory',['tools/verify_artifacts.py'])]:
  r.run('closure-precommit-'+name,[r.PY,'-B',*args],REPO)
 core_audit.audit(REPO,'final-candidate-before-closure-commit')
 r.run('closure-stage',['git','add','--',*sorted(pack.ALLOWED)],REPO)
 r.run('closure-commit',['git','commit','-m','Record verified PR12/PR13 integration replay and frozen Core evidence'],REPO)
 head,tree=git('rev-parse','HEAD'),git('rev-parse','HEAD^{tree}')
 require(set(git('diff','--name-only',pack.CANDIDATE,head).splitlines())==pack.ALLOWED,'committed scope changed')
 pack.source_closure('FINAL_SOURCE_CLOSURE.json')
 core_audit.audit(REPO,'final-candidate-committed')
 r.run('closure-final-core',[r.PY,'-B','tools/erc8404/integrity.py'],REPO)
 r.run('closure-final-preservation',[r.PY,'-B','tools/pr12_pr13_integration/preservation.py','--fuzz'],REPO)
 r.run('closure-final-inventory',[r.PY,'-B','tools/verify_artifacts.py'],REPO)
 r.run('closure-final-status',['git','status','--porcelain=v1'],REPO)
 require((ROOT/'logs/closure-final-status.stdout').read_bytes()==b'','final worktree dirty')
 closure_logs={p.name:sha(p.read_bytes()) for p in sorted((ROOT/'logs').glob('closure-*')) if p.is_file()}
 final={'schema':'veca-local-integration-closure-v1','completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'verdict':'READY_FOR_INDEPENDENT_REVIEW','ERC8404_CORE_UNCHANGED':'PASS',
  'repository':'https://github.com/trustless-ai/verifiable-execution-claim-authorization',
  'branch':git('branch','--show-current'),'head':head,'tree':tree,'executed_source_commit':pack.CANDIDATE,
  'executed_source_tree':source['executed_tree'],'unchanged_source_config_fixture_and_other_nonclosure_files':source['unchanged_files'],
  'closure_only_paths':sorted(pack.ALLOWED),'clean_worktree':True,'production':'HOLD',
  'aggregate_inventory_exception':source['aggregate_inventory_exception'],
  'remote_write_performed':False,'hosted_candidate_ci':'NOT_RUN','independent_human_review':'NOT_ESTABLISHED',
  'report':str(REPO/'research/pr12-pr13-integration-v1/REPORT.md'),'evidence':str(archive),
  'archive_sha256':sha(archive.read_bytes()),'report_sha256':sha((REPO/'research/pr12-pr13-integration-v1/REPORT.md').read_bytes()),
  'final_source_proof_sha256':sha((ROOT/'FINAL_SOURCE_CLOSURE.json').read_bytes()),
  'final_core_git_object_audit_sha256':sha((ROOT/'core-audits/final-candidate-committed.json').read_bytes()),
  'closure_log_sha256':closure_logs}
 r.save(ROOT/'FINAL_CLOSURE.json',final)
 print(json.dumps({k:v for k,v in final.items() if k!='closure_log_sha256'},indent=2))

if __name__=='__main__':main()
