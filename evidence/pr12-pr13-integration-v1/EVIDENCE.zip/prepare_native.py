"""Populate isolated pinned public source clones; build native dependencies afresh."""
import importlib.util,json,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('b',Path(__file__).with_name('baselines.py'));b=importlib.util.module_from_spec(s);s.loader.exec_module(b);r=b.r
root=r.ROOT/'fresh'
sources=json.loads((root/'evidence/v3/discovery/sources.json').read_bytes())+[json.loads((root/'evidence/v3/public/ccip-router-source.json').read_bytes())]
for source in sources:
 if source['repository']=='ethereum/ERCs':continue
 name=source['repository'].split('/')[1];dest=root/'build/v3/upstream'/name
 dest.parent.mkdir(parents=True,exist_ok=True)
 r.run('fresh-source-clone-'+name,['git','-c','core.autocrlf=false','clone','--no-hardlinks',b.DONOR/'build/v3/upstream'/name,dest],root)
 r.run('fresh-source-pin-'+name,['git','-C',dest,'checkout','--detach',source['commit']],root)
 r.run('fresh-source-status-'+name,['git','-C',dest,'status','--porcelain'],root)
r.run('fresh-native-prepare',[r.PY,'-B','tools/v3/prepare.py'],root,allow=True)
