"""Independent Git-object audit, outside the candidate and its manifests."""
from pathlib import Path
import hashlib,json,subprocess,sys,datetime
ROOT=Path(__file__).resolve().parent
MAIN='999e7047df15585f8ce0629081a1369a4942353f'
CORE='9dd36e882dd372f264b77b179130948aa5adcbde'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def blob(repo,ref,path):return git(repo,'show',ref+':'+path)
def blobs(repo,ref,paths):
    proc=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=''.join(ref+':'+p+'\n' for p in paths).encode(),capture_output=True,check=True)
    data=proc.stdout;pos=0;result={}
    for p in paths:
        end=data.index(b'\n',pos);head=data[pos:end].split();size=int(head[2]);pos=end+1
        result[p]=(head[0].decode(),data[pos:pos+size]);pos+=size+1
    return result
def audit(target,label):
    target=Path(target);base=json.loads(blob(target,MAIN,'artifacts.sha256.json'))['files']
    # Freeze every main file, then explicitly enumerate the Core-related subset.
    protected={p:d for p,d in base.items() if 'erc8404' in p.lower()}
    rows={};objects=blobs(target,MAIN,list(protected))
    for p,d in protected.items():
        oid,raw=objects[p]
        rows[p]={'baseline_sha256':sha(raw),'git_blob':oid,
                 'observed_sha256':sha((target/p).read_bytes()) if (target/p).is_file() else None}
        if sha(raw)!=d:raise ValueError('main inventory vs Git disagreement '+p)
    pins=json.loads(blob(target,MAIN,'fixtures/erc8404/core-lock.json'))
    upstream=json.loads(blob(target,MAIN,'evidence/erc8404/upstream-tree-baseline.json'))
    tree=git(ROOT/'core-objects','ls-tree','-r','--name-only',CORE).decode().splitlines()
    up=blobs(ROOT/'core-objects',CORE,tree)
    upstream_rows={p:{'sha256':sha(up[p][1]),'git_blob':up[p][0]} for p in tree}
    if set(tree)!=set(upstream) or any(upstream_rows[p]['sha256']!=d for p,d in upstream.items()):raise ValueError('75-file upstream baseline mismatch')
    if any(upstream_rows[p]['sha256']!=d or rows['evidence/erc8404/core/'+p]['observed_sha256']!=d for p,d in pins.items()):raise ValueError('vendored Core differs from upstream objects')
    if any(v['baseline_sha256']!=v['observed_sha256'] for v in rows.values()):raise ValueError('protected Core-related bytes differ')
    observed_core={p.relative_to(target/'evidence/erc8404/core').as_posix() for p in (target/'evidence/erc8404/core').rglob('*') if p.is_file()}
    if observed_core!=set(pins):raise ValueError('Core file set changed')
    result={'schema':'veca-core-git-object-audit-v1','label':label,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'head':git(target,'rev-parse','HEAD').decode().strip(),'baseline_main':MAIN,'upstream_commit':CORE,
            'upstream_files':upstream_rows,'protected_files':rows,'vendored_files':len(pins),'passed':True,
            'runtime_binding':'NOT_CHECKED_BY_THIS_BYTE_AUDIT'}
    out=ROOT/'core-audits'/(label+'.json');out.parent.mkdir(exist_ok=True)
    if out.exists():raise ValueError('would overwrite audit')
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'passed':True,'protected_files':len(rows),'upstream_files':len(tree),'vendored_files':len(pins)}))
if __name__=='__main__':audit(sys.argv[1],sys.argv[2])
