"""Audit original inventories against immutable Git blobs, independently of checkout seals."""
import importlib.util,json,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('a',Path(__file__).with_name('core_audit.py'));a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
root=a.ROOT/'integration'
policy=json.loads((root/'research/pr12-pr13-integration-v1/TRANSITION.json').read_bytes())
results={}
for ref,pin in policy['source_manifest_sha256'].items():
 raw=a.blob(root,ref,'artifacts.sha256.json')
 if a.sha(raw)!=pin:raise ValueError('original manifest identity mismatch')
 inventory=json.loads(raw)['files'];objects=a.blobs(root,ref,list(inventory))
 bad=[p for p,d in inventory.items() if a.sha(objects[p][1])!=d]
 if bad:raise ValueError('original Git inventory mismatch '+repr(bad[:10]))
 results[ref]={'manifest_sha256':pin,'tree':a.git(root,'rev-parse',ref+'^{tree}').decode().strip(),
  'files':len(inventory),'passed':True,'entries':{p:{'git_blob':objects[p][0],'sha256':d} for p,d in inventory.items()}}
 del objects
 print(ref,len(inventory),'PASS',flush=True)
for path,ref in [('conformance/erc8004-property-fuzz-v0/baseline-inventory.json','80c91a09095eca362dbfb69d39d0c01fc31130cf'),('conformance/spec-drift-coverage-v0/baseline-inventory.json','6e8fabee9be170245f557a271b6d315176cc4a03')]:
 if (root/path).read_bytes()!=a.blob(root,ref,'artifacts.sha256.json'):raise ValueError('initial manifest bytes changed')
(a.ROOT/'HISTORICAL_GIT_AUDIT.json').write_text(json.dumps({'schema':'veca-historical-git-inventory-audit-v1','passed':True,'baselines':results},indent=2)+'\n',encoding='utf-8',newline='\n')
