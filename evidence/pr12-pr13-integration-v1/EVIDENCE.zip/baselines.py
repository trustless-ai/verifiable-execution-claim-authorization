"""Fresh pinned baseline execution; caches are copied only after pin checks."""
import importlib.util,json
from pathlib import Path
s=importlib.util.spec_from_file_location('receipt',Path(__file__).with_name('run.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
DONOR=Path('D:/PAVLO HQ/Workspaces/veca-pr12-integration-v1-20261104/fresh')
def prepare(name,evm=True):
    root=r.ROOT/name
    r.run(name+'-grader',[r.PY,'-B','tools/agent_harness.py','prepare','--source',DONOR/'build/agent-harness-v0/recompute-kit'],root)
    if evm:
        lock=json.loads((root/'conformance/erc8004-pilot-v0/source-lock.json').read_bytes())
        for kind in ('implementation','specification'):
            item=lock[kind]
            for p,d in item.get('files',{item.get('path'):item.get('sha256')}).items():
                raw=(DONOR/'build/erc8004'/kind/p).read_bytes()
                if r.sha(raw)!=d:raise ValueError('Cache not pinned: '+p)
                target=root/'build/erc8004'/kind/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        r.run(name+'-erc8004-prepare',[r.PY,'-B','tools/erc8004/prepare.py'],root)
        r.run(name+'-crypto-prepare',[r.PY,'-B','research/formal-v1/prepare_crypto.py'],root)
        r.run(name+'-crypto-npm',['C:/Program Files/nodejs/npm.cmd','ci','--ignore-scripts','--no-audit','--no-fund','--prefix','build/formal-v1/crypto'],root)
    return root
if __name__=='__main__':
    root=prepare('baseline-pr12')
    r.run('baseline-pr12-validate',[r.PY,'-B','tools/erc8004_fuzz/validate.py','--out','build/integration-review-baseline'],root,allow=True)
    root=prepare('baseline-pr13',False)
    r.run('baseline-pr13-validate',[r.PY,'-B','tools/spec_drift_coverage/validate.py','--out','build/integration-review-baseline'],root,allow=True)
    root=prepare('baseline-main')
    for label,args in [('inventory',['tools/verify_artifacts.py']),('core',['tools/erc8404/integrity.py']),('pilot',['tools/erc8004/validate.py','--out','build/integration-review-baseline']),('harness',['tools/harness_v0/validate.py','--out','build/integration-review-harness'])]:
        r.run('baseline-main-'+label,[r.PY,'-B',*args],root,allow=True)
