"""Bind the post-resolution Core checks to actual committed merge trees."""
from pathlib import Path
import datetime,hashlib,json,subprocess
from core_audit import blobs,MAIN
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'integration'
pins=json.loads(subprocess.check_output(['git','show',MAIN+':artifacts.sha256.json'],cwd=REPO))['files']
protected=sorted(p for p in pins if 'erc8404' in p.lower())
baseline=blobs(REPO,MAIN,protected)
stages={}
for label,commit in [('after-pr12','e381642352f795ff0ed80ffc8ca0e5b368c5f65e'),('after-pr13','f00757bc17f5d35d203f00639a1d20b01f1ed438')]:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=REPO).decode().splitlines()
 if sorted(p for p in paths if 'erc8404' in p.lower())!=protected:raise ValueError('Core-related path set changed: '+label)
 observed=blobs(REPO,commit,protected);rows={}
 for path,(oid,raw) in observed.items():
  digest=hashlib.sha256(raw).hexdigest()
  if (oid,raw)!=baseline[path] or digest!=pins[path]:raise ValueError('committed Core changed: '+path)
  rows[path]={'git_blob':oid,'sha256':digest}
 stages[label]={'commit':commit,'tree':subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=REPO).decode().strip(),
                'protected_file_count':len(rows),'files':rows,'passed':True}
result={'schema':'veca-committed-merge-core-audit-v1','passed':True,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseline_main':MAIN,'stages':stages,
        'relation_to_stage_checks':'The earlier filesystem/checker audits ran after conflict resolution and before each merge commit; this verifies the exact committed merge objects separately.',
        'independent_human_review':False}
(ROOT/'COMMITTED_MERGE_CORE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'passed':True,'committed_merge_trees':len(stages),'protected_paths_per_tree':len(protected)}))
