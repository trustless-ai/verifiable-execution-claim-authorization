"""Record only confirmed local closure; preserve prior Memory Palace content."""
from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parent
PALACE=Path('D:/PAVLO HQ/AI Memory Palace')
MARKER='VECA-PR12-PR13-INTEGRATION-V1-20261119'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,message):
    if not ok:raise ValueError(message)

def main():
    final=json.loads((ROOT/'FINAL_CLOSURE.json').read_bytes())
    require(final['verdict']=='READY_FOR_INDEPENDENT_REVIEW' and final['ERC8404_CORE_UNCHANGED']=='PASS','closure not established')
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'integration').decode().strip()==final['head'],'final HEAD moved')
    require(not subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT/'integration'),'final tree dirty')
    require(sha(Path(final['evidence']).read_bytes())==final['archive_sha256'],'archive changed')
    remote=json.loads((ROOT/'REMOTE_CLOSURE.json').read_bytes())
    require(remote['matches_preflight_source_refs'],'source refs changed')
    common=(
        '## 2026-11-19 - '+MARKER+'\n\n'
        '- Status: READY_FOR_INDEPENDENT_REVIEW; ERC8404_CORE_UNCHANGED: PASS; production HOLD.\n'
        '- Repository: trustless-ai/verifiable-execution-claim-authorization. Local branch `'+final['branch']+'`.\n'
        '- Final local HEAD `'+final['head']+'`; tree `'+final['tree']+'`. Full replay source `'+final['executed_source_commit']+'`; closing commit changes only new report/evidence plus their five aggregate-inventory leaf hashes. All 12,822 other tracked files are byte-identical to the executed source candidate.\n'
        '- Read-only GitHub closure observation '+remote['observed_at']+': main `'+remote['main']+'`; PR12 `'+remote['pulls']['12']['headRefOid']+'`; PR13 `'+remote['pulls']['13']['headRefOid']+'`. Observed statuses: '+', '.join('PR'+n+' '+remote['pulls'][n]['state']+' / draft='+str(remote['pulls'][n]['isDraft']) for n in ('12','13'))+'. No remote write, push, remote merge, comment or PR-status change.\n'
        '- New isolated task root: `'+str(ROOT)+'`; branch worktree `integration`, clean replay worktree `fresh`, detached baselines `baseline-main`, `baseline-pr12`, `baseline-pr13`. Pre-existing worktrees untouched.\n'
        '- Frozen Core: pinned RVR 9dd36e882dd372f264b77b179130948aa5adcbde; formal draft 7a9e63a80bce04db53c6550103c1d41eca35f3d1. 13 vendored files, all 75 upstream files, 4,653 Core-related paths verified with Git objects/SHA-256; runtime observed 36 real recompute calls from the pinned adapter. No Core changes or mutation targets.\n'
        '- Actual pinned baseline and clean-candidate replay: 300 generated cases per normal/repeat/-O; six physical Solidity mutations KILLED in normal and -O, three positive controls each, original 29-case matrix misses all six, minimized witnesses and backend/source restoration verified.\n'
        '- PR13: original 32 controls pass at its own SHA. Integrated population explicitly 31 original semantic controls + 1 versioned preservation control; 13 transport controls; offline normal/repeat/-O outputs identical to original; 51 obligations audited. Separate live source capture retained; no pins updated.\n'
        '- Six physical preservation tamper controls REJECTED in normal/repeat/-O with positive/restoration controls. All 17 workflow families covered by local commands. Hosted candidate CI NOT_RUN; local Windows success is not hosted Ubuntu CI.\n'
        '- External transition pins exact original manifests and three pre-existing main differences; Core changes forbidden. Old guards and historical reports/evidence unchanged. Old-contract refusal recorded rather than relabelled PASS.\n'
        '- Retained limitations: external Core-consumer 16 KILLED / 1 SURVIVED; original v2 18 KILLED / 2 SURVIVED / 1 UNVERIFIABLE, distinct from later survivor controls; PR11 original-matrix probe 1 KILLED / 4 SURVIVED, distinct from isolated 4 KILLED; escrow 6 NOT_APPLIED absent checks; finite v3/v4 coverage. Same Codex executor; independent human/organizational review NOT_ESTABLISHED. No production, funds or new end-to-end pilot.\n'
        '- Report: `'+final['report']+'`. Evidence: `'+final['evidence']+'`. Final exact HEAD/tree, command checks and source-closure proof: `'+str(ROOT/'FINAL_CLOSURE.json')+'`.\n'
        '- Evidence archive SHA-256 `'+final['archive_sha256']+'`. Next: independent review/replay only; no authorization to push or merge is implied.\n\n'
    )
    names=['Topics/Verifiable AI Guarantee Composition.md','Repositories/Trustless AI.md',
           'Repositories/Local Worktrees.md','CURRENT_HANDOFF.md','WORKSPACE_MAP.md','SESSION_LOG.md']
    before={name:(PALACE/name).read_bytes() for name in names}
    require(all(MARKER.encode() not in raw for raw in before.values()),'memory closure already recorded')
    updates={}
    for name,raw in before.items():
        if name=='SESSION_LOG.md':updated=raw+(b'' if raw.endswith(b'\n') else b'\n')+b'\n'+common.encode()
        else:
            title,separator,rest=raw.partition(b'\n')
            require(bool(separator),'unexpected note layout: '+name)
            updated=title+separator+b'\n'+common.encode()+rest
        updates[name]=updated
    # Detect concurrent note edits immediately before each write.
    receipts=[]
    for name,updated in updates.items():
        path=PALACE/name
        require(path.read_bytes()==before[name],'concurrent Memory Palace edit: '+name)
        path.write_bytes(updated)
        require(path.read_bytes()==updated,'memory write did not persist')
        receipts.append({'path':str(path),'before_sha256':sha(before[name]),'after_sha256':sha(updated),'historical_content_preserved':True})
    (ROOT/'MEMORY_CLOSURE.json').write_text(json.dumps({'marker':MARKER,'final_head':final['head'],'updates':receipts},indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'memory_notes_updated':len(receipts),'final_head':final['head']}))

if __name__=='__main__':main()
