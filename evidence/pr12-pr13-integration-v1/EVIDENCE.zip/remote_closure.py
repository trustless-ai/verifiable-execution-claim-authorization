"""Read-only final observation; never publish or mutate remote refs or PRs."""
from pathlib import Path
import datetime,importlib.util,json,subprocess
ROOT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('r',ROOT/'run.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
repo='trustless-ai/verifiable-execution-claim-authorization'
r.run('closure-remote-main',['gh','api','repos/'+repo+'/commits/main','--jq','.sha'],ROOT)
main=(ROOT/'logs/closure-remote-main.stdout').read_text().strip()
pulls={}
for number in (12,13):
 label='closure-remote-pr'+str(number)
 r.run(label,['gh','pr','view',str(number),'--repo',repo,'--json','number,state,isDraft,baseRefName,baseRefOid,headRefName,headRefOid,url,updatedAt'],ROOT)
 pulls[str(number)]=json.loads((ROOT/'logs'/(label+'.stdout')).read_bytes())
pre=json.loads((ROOT/'PREFLIGHT.json').read_bytes())
same=main==pre['main'] and all(pulls[str(n)]['headRefOid']==pre['pr'+str(n)] for n in (12,13))
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'main':main,'pulls':pulls,
        'matches_preflight_source_refs':same,'remote_write_performed':False,
        'local_branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT/'integration').decode().strip(),
        'hosted_candidate_ci':'NOT_RUN: candidate was not pushed'}
r.save(ROOT/'REMOTE_CLOSURE.json',result)
if not same:raise RuntimeError('Remote source refs moved; integration relationship must be reviewed')
print(json.dumps({'matches_preflight_source_refs':same,'main':main}))
