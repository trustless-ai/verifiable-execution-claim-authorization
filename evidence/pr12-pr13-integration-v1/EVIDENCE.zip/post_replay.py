"""Remaining matrix and raw backend audits after every serial campaign finishes."""
import importlib.util,json,time,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('r',Path(__file__).with_name('run.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
deadline=time.monotonic()+18000
print('Waiting for final serial campaigns; no concurrent mutation work.',flush=True)
while not (r.ROOT/'FINAL_SERIAL_DONE.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('Final replay deadline exceeded')
 time.sleep(5)
py313=json.loads((r.ROOT/'PY313.json').read_bytes())['executable']
r.run('fresh-final-v0-python313',[py313,'-B','tools/validate.py','--out','build/final/v0-python313'],r.ROOT/'fresh',allow=True)
for label,path in [
 ('baseline-pr12-optimized','baseline-pr12/build/integration-review-mutations-optimized'),
 ('candidate-normal','fresh/build/final/fuzz/mutations'),
 ('candidate-optimized','fresh/build/final/fuzz/mutations-optimized')]:
 r.run('backend-audit-'+label,[r.PY,'-I','-S','-B','-X','utf8','mutation_backend_audit.py',path,'audits/'+label+'.json'],r.ROOT,allow=True)
r.run('final-core-integrity',[r.PY,'-B','tools/erc8404/integrity.py'],r.ROOT/'fresh',allow=True)
r.run('final-artifact-integrity',[r.PY,'-B','tools/verify_artifacts.py'],r.ROOT/'fresh',allow=True)
r.run('final-source-status',['git','status','--porcelain=v1'],r.ROOT/'fresh')
r.save(r.ROOT/'POST_REPLAY_DONE.json',{'completed':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r.ROOT/'fresh').decode().strip()})
