"""Serialize every physical mutation campaign; all source worktrees are isolated."""
import importlib.util,json,os,subprocess,time
from pathlib import Path
def module(name):
 s=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
r=module('run');a=module('core_audit');root=r.ROOT/'fresh'
os.environ['PATH']='C:/Users/msi/.foundry/bin;C:/Users/msi/.bun/bin;'+os.environ['PATH']
os.environ['FORGE']='C:/Users/msi/.foundry/bin/forge.exe'
deadline=time.monotonic()+10800
done=r.ROOT/'logs/baseline-main-harness.json'
print('Waiting for all pinned baseline campaigns to finish before fresh physical mutations.',flush=True)
while not done.exists():
 if time.monotonic()>deadline:raise RuntimeError('Baseline deadline exceeded; not a test pass')
 time.sleep(5)
for name in ('baseline-pr12-validate','baseline-pr13-validate','baseline-main-pilot','baseline-main-harness'):
 receipt=json.loads((r.ROOT/'logs'/(name+'.json')).read_bytes())
 if receipt['exit_code']!=0:raise RuntimeError('Baseline failure must be diagnosed first: '+name)
if subprocess.check_output(['git','status','--porcelain'],cwd=root):raise RuntimeError('Fresh candidate not clean')
r.run('baseline-pr12-mutations-optimized',[r.PY,'-B','-O','tools/erc8004_fuzz/mutations.py','--out','build/integration-review-mutations-optimized'],r.ROOT/'baseline-pr12')
plan=[
 ('fuzz',['tools/pr12_pr13_integration/fuzz_validate.py','--out','build/final/fuzz']),
 ('harness',['tools/harness_v0/validate.py','--out','build/final/harness']),
 ('harness-mutations-optimized',['-O','tools/harness_v0/mutations.py','--out','build/final/harness-mutations-optimized']),
 ('supplement',['tools/harness_v0/review_validate.py','--out','build/final/supplement']),
 ('role-policy-v1',['tools/erc8004_role_policy/validate.py','--out','build/final/role-v1']),
 ('role-policy-v2',['tools/erc8004_role_policy_v2/validate.py','--out','build/final/role-v2']),
 ('legacy-mutations-optimized',['-O','tools/erc8004/mutations.py','--out','build/final/legacy-mutations-optimized']),
 ('core-consumer',['tools/erc8404/validate.py','--out','build/final/core-consumer']),
 ('core-benchmark',['tools/erc8404/benchmark.py']),
 ('v0',['tools/validate.py','--out','build/final/v0']),
 ('formal-v1',['research/formal-v1/validate.py','--out','build/final/formal-v1']),
 ('v2-statement',['tools/v2/statement.py']),
 ('v2',['tools/v2/validate.py','--out','build/final/v2']),
 ('v2-snapshot',['tools/v2/check_snapshot.py','--out','build/final/v2']),
 ('v2-survivors',['tools/v2/validate_survivors.py','--out','build/final/v2-survivors']),
 ('v3',['tools/v3/validate.py','--out','build/final/v3']),
 ('v4',['tools/v4/validate.py','--out','build/final/v4']),
 ('v4_1-run',['tools/v4_1/run.py']),
 ('v4_1-tests',['-m','unittest','discover','-s','tests/v4_1','-v']),
 ('v4_1-tests-optimized',['-O','-m','unittest','discover','-s','tests/v4_1','-v']),
 ('v4_1-mutations',['tools/v4_1/mutations.py','--out','build/final/v4_1-mutations']),
 ('v4_1-mutations-optimized',['-O','tools/v4_1/mutations.py','--out','build/final/v4_1-mutations-optimized']),
 ('claim-integration',['tools/integration/validate.py','--out','build/final/claim-integration']),
 ('escrow',['tools/escrow_ci.py','--out','build/final/escrow']),
]
for name,args in plan:
 r.run('fresh-final-'+name,[r.PY,'-B',*args],root,allow=True)
for mode,flags in [('normal',[]),('repeat',[]),('optimized',['-O'])]:
 r.run('fresh-final-preservation-'+mode,[r.PY,'-B',*flags,'tools/pr12_pr13_integration/controls.py','--out','build/final/preservation-'+mode],root,allow=True)
for name,args in [('core',['tools/erc8404/integrity.py']),('preservation',['tools/pr12_pr13_integration/preservation.py','--fuzz']),('inventory',['tools/verify_artifacts.py'])]:
 r.run('fresh-final-end-'+name,[r.PY,'-B',*args],root)
a.audit(root,'fresh-candidate-after')
r.run('fresh-final-status',['git','status','--porcelain=v1'],root)
r.run('fresh-final-diff-check',['git','diff','--check'],root)
r.save(r.ROOT/'FINAL_SERIAL_DONE.json',{'completed':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'plan_labels':[x[0] for x in plan]})
