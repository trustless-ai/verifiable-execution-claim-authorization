"""Package newly executed raw evidence only; do not reseal historical entries."""
from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path(__file__).resolve().parent
CANDIDATE='5ebabe818173ffdb87dd9018d60c43ed77002c1a'
ALLOWED={
 'artifacts.sha256.json',
 'research/pr12-pr13-integration-v1/REPORT.md',
 'evidence/pr12-pr13-integration-v1/README.md',
 'evidence/pr12-pr13-integration-v1/RESULTS.json',
 'evidence/pr12-pr13-integration-v1/EVIDENCE.zip',
 'evidence/pr12-pr13-integration-v1/SHA256.json',
}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
def require(ok,msg):
 if not ok:raise ValueError(msg)

def source_closure(label='SOURCE_CLOSURE.json'):
 from core_audit import blobs
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',CANDIDATE],cwd=ROOT/'integration').decode().splitlines()
 objects=blobs(ROOT/'integration',CANDIDATE,[p for p in paths if p not in ALLOWED]);rows={}
 for path,(oid,raw) in objects.items():
  same={tree:(ROOT/tree/path).is_file() and (ROOT/tree/path).read_bytes()==raw for tree in ('integration','fresh')}
  require(all(same.values()),'executed source/config/fixture changed: '+path)
  rows[path]={'git_blob':oid,'sha256':sha(raw),'matches':same}
 status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT/'fresh').decode()
 require(status=='','fresh checkout is no longer clean')
 original_raw=subprocess.check_output(['git','show',CANDIDATE+':artifacts.sha256.json'],cwd=ROOT/'integration')
 original=json.loads(original_raw)
 current_raw=(ROOT/'integration/artifacts.sha256.json').read_bytes();current=json.loads(current_raw)
 require({k:v for k,v in original.items() if k!='files'}=={k:v for k,v in current.items() if k!='files'},'inventory schema/exclusions changed')
 require(set(original['files'])==set(current['files']),'closure changed inventory membership')
 delta={p:{'before':d,'after':current['files'][p]} for p,d in original['files'].items() if current['files'][p]!=d}
 require(set(delta)<=ALLOWED-{'artifacts.sha256.json'},'closure changed a source/config/fixture inventory entry')
 require((ROOT/'fresh/artifacts.sha256.json').read_bytes()==original_raw,'executed checkout inventory changed')
 result={'schema':'veca-source-closure-v1','passed':True,'executed_commit':CANDIDATE,
         'executed_tree':subprocess.check_output(['git','rev-parse',CANDIDATE+'^{tree}'],cwd=ROOT/'integration').decode().strip(),
         'closure_only_paths':sorted(ALLOWED),'unchanged_files':len(rows),'files':rows,'fresh_status':status,
         'aggregate_inventory_exception':{'baseline_sha256':sha(original_raw),'current_sha256':sha(current_raw),
          'changed_leaf_entries':delta,'schema_exclusions_and_membership_unchanged':True,
          'source_config_fixture_entries_unchanged':True}}
 save(ROOT/label,result)
 return result

def members():
 chosen={};omitted={}
 def add(path):
  rel=path.relative_to(ROOT).as_posix()
  require(not path.is_symlink(),'symlink in evidence: '+rel)
  require(not any(part in {'.git','node_modules','__pycache__','target'} for part in path.relative_to(ROOT).parts),'dependency/cache selected: '+rel)
  parts=path.relative_to(ROOT).parts
  # Full mutated source copies stay in disposable execution evidence outside the
  # committed candidate. Keep hashes, replacements, input vectors and actual
  # backend observations; omit compiler caches which embed those source copies.
  source_copy=len(parts)>1 and parts[0] in {'fresh','integration','baseline-pr12','baseline-pr13','baseline-main'} and path.suffix.lower() in {'.sol','.py','.js','.mjs','.cjs','.ts','.toml'}
  compiler_copy='onchain-mutations' in parts and any(p in {'out','cache'} for p in parts)
  if source_copy or compiler_copy:
   omitted[rel]={'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'reason':'full source snapshot' if source_copy else 'generated compiler artifact/cache may embed source','retained_at_original_task_workspace_path':True}
   return
  chosen[rel]=path
 for pattern in ('*.py','*.json'):
  for path in ROOT.glob(pattern):
   if path.name not in {'FINAL_CLOSURE.json','PACKAGE_RESULT.json'}:add(path)
 add(ROOT/'report_template.md')
 dirs=['logs','core-audits','audits',
  'baseline-pr12/build/integration-review-baseline',
  'baseline-pr12/build/integration-review-mutations-optimized',
  'baseline-pr13/build/integration-review-baseline',
  'baseline-main/build/integration-review-baseline',
  'baseline-main/build/integration-review-harness',
  'fresh/build/final','fresh/build/escrow/ci-integration-v1','fresh/build/v2/native','fresh/build/v3/setup-replay',
  'integration/build/integration-smoke']
 for folder in dirs:
  base=ROOT/folder
  require(base.is_dir(),'required evidence directory missing: '+folder)
  for path in sorted(base.rglob('*')):
   if path.is_file():add(path)
 for path in ['fresh/build/python-install.json','fresh/build/escrow/setup.json']:
  require((ROOT/path).is_file(),'setup evidence missing: '+path);add(ROOT/path)
 omission=ROOT/'ARCHIVE_OMISSIONS.json'
 save(omission,{'schema':'veca-integration-archive-source-omissions-v1','purpose':'No complete mutated source copies are imported into the committed integration candidate. Original task-local files remain available; runtime/source/compiler hashes and mutation replacements remain archived.','files':dict(sorted(omitted.items()))})
 chosen[omission.name]=omission
 return dict(sorted(chosen.items()))

def package():
 require((ROOT/'POST_REPLAY_DONE.json').is_file(),'executions incomplete')
 require(read(ROOT/'ESCROW_RETRY_DONE.json')['passed'],'escrow retry incomplete')
 require(read(ROOT/'REPLAY_COMPARISON.json')['passed'],'comparison incomplete')
 source_closure()
 selected=members(); hashes={};total=0
 target=ROOT/'integration/evidence/pr12-pr13-integration-v1/EVIDENCE.zip'
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,path in selected.items():
   raw=path.read_bytes();hashes[name]=sha(raw);total+=len(raw)
   info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 with zipfile.ZipFile(target) as z:
  require(set(z.namelist())==set(hashes),'archive membership mismatch')
  require(z.testzip() is None,'archive CRC failure')
  require(all(sha(z.read(n))==d for n,d in hashes.items()),'archive bytes differ')
 result={'schema':'veca-integration-archive-v1','archive_sha256':sha(target.read_bytes()),
         'archive_bytes':target.stat().st_size,'uncompressed_bytes':total,'member_count':len(hashes),'members':hashes,
         'all_members_roundtrip_verified':True,'executed_candidate':CANDIDATE}
 save(ROOT/'PACKAGE_RESULT.json',result)
 print(json.dumps({k:v for k,v in result.items() if k!='members'}))
 return result

if __name__=='__main__':package()
