import importlib.util,subprocess,json
from pathlib import Path
def module(name):
 s=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=module('baselines');r=b.r;a=module('core_audit')
root=b.prepare('fresh')
for name,args in [('python',[r.PY,'--version']),('node',['node','--version']),('npm',['C:/Program Files/nodejs/npm.cmd','--version']),('bun',['C:/Users/msi/.bun/bin/bun.exe','--version']),('git',['git','--version'])]:r.run('fresh-version-'+name,args,root)
r.run('fresh-python-locked-deps',[r.PY,'-m','pip','install','--disable-pip-version-check','--no-deps','--require-hashes','--target','build/v3/python-deps','--report','build/python-install.json','-r','research/v3/requirements.lock.txt'],root,allow=True)
a.audit(root,'fresh-candidate-before')
for name,args in [('spec',['tools/pr12_pr13_integration/spec_validate.py','--out','build/final/spec']),('runtime',['tools/pr12_pr13_integration/runtime_binding.py','--out','build/final/core-binding']),('core-integrity',['tools/erc8404/integrity.py']),('integration-integrity',['tools/integration/integrity.py'])]:
 r.run('fresh-'+name,[r.PY,'-B',*args],root,allow=True)
for mode,flags in [('normal',[]),('repeat',[]),('optimized',['-O'])]:
 r.run('fresh-core-python-'+mode,[r.PY,'-B',*flags,'evidence/erc8404/core/conformance/rvr-v0/adapter.py','--check'],root)
 for tests in ['baseline_reconciliation','erc8004_role_policy','erc8004_role_policy_v2','harness_review']:
  r.run('fresh-tests-'+tests+'-'+mode,[r.PY,'-B',*flags,'-m','unittest','discover','-s','tests/'+tests,'-v'],root,allow=True)
for mode in ('normal','repeat'):
 r.run('fresh-core-typescript-'+mode,['C:/Users/msi/.bun/bin/bun.exe','evidence/erc8404/core/conformance/rvr-v0/adapter.ts','--check'],root,allow=True)
r.run('fresh-live-drift',[r.PY,'-B','tools/pr12_pr13_integration/spec_cli.py','drift','--live','--out','build/final/live-drift'],root,allow=True)
r.run('fresh-semantics-status',['git','status','--porcelain=v1'],root)
r.save(r.ROOT/'FRESH_SEMANTICS_DONE.json',{'completed':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()})
