"""Isolated second CI-matrix interpreter; no registry, PATH, or project changes."""
import importlib.util,os,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('r',Path(__file__).with_name('run.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
os.environ['UV_CACHE_DIR']=str(r.ROOT/'toolchains/uv-cache')
dest=r.ROOT/'toolchains/python'
r.run('python313-prepare',['C:/Users/msi/AppData/Local/hermes/bin/uv.exe','python','install','3.13','--install-dir',dest,'--no-bin','--no-registry','--no-config'],r.ROOT)
paths=list(dest.glob('cpython-3.13.*/python.exe'))
if len(paths)!=1:raise RuntimeError('ambiguous interpreter')
exe=paths[0].resolve();version=subprocess.check_output([str(exe),'--version']).decode().strip()
r.save(r.ROOT/'PY313.json',{'executable':str(exe),'version':version,'sha256':r.sha(exe.read_bytes()),'global_configuration_changed':False})
print(version)
