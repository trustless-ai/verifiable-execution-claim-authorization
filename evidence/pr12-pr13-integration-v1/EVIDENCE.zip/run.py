"""Task-owned command receipts; no remote writes or implicit source resets."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
PY=Path('C:/Users/msi/AppData/Local/Programs/Python/Python312/python.exe')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def run(name,args,cwd=None,allow=False,timeout=10800):
    out=ROOT/'logs'/name;out.parent.mkdir(parents=True,exist_ok=True)
    if out.with_suffix('.json').exists():raise RuntimeError('Existing command receipt '+name)
    start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_TERMINAL_PROMPT='0',CI='true')
    with out.with_suffix('.stdout').open('wb') as stdout,out.with_suffix('.stderr').open('wb') as stderr:
        proc=subprocess.run([str(a) for a in args],cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
    result={'name':name,'argv':[str(a) for a in args],'cwd':str(cwd) if cwd else None,'started_utc':started,'seconds':time.monotonic()-start,'exit_code':proc.returncode,'stdout_sha256':sha(out.with_suffix('.stdout').read_bytes()),'stderr_sha256':sha(out.with_suffix('.stderr').read_bytes())}
    save(out.with_suffix('.json'),result);print(json.dumps(result),flush=True)
    if proc.returncode and not allow:raise RuntimeError('Command failed; evidence retained: '+name)
    return proc.returncode
if __name__=='__main__':
    # Usage: run.py label cwd command ...
    run(sys.argv[1],sys.argv[3:],sys.argv[2],allow=True)
