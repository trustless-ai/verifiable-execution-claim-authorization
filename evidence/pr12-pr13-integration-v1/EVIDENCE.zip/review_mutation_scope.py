"""Record inspected mutation write targets; this is a static review, not execution proof."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
reviewed={
 'tools/erc8004_fuzz/mutations.py':'Disposable contracts/IdentityRegistryUpgradeable.sol or ValidationRegistryUpgradeable.sol; original build source remains unchanged.',
 'tools/erc8004/mutations.py':'Disposable ERC8004 Solidity / external adapter copies; no Core mutation.',
 'tools/harness_v0/mutations.py':'Disposable src/erc8404/engine.py external consumer; exact Core files and lock copied unchanged and consumed through that consumer.',
 'tools/harness_v0/review_controls.py':'Disposable external src/erc8404/engine.py; original Core is copied without editing.',
 'tools/erc8004_role_policy/mutations.py':'Disposable external tools/erc8004_role_policy/policy.py.',
 'tools/erc8004_role_policy_v2/mutations.py':'Disposable external tools/erc8004_role_policy_v2/policy.py.',
 'tools/erc8404/mutations.py':'build output worker copies of src/erc8404/engine.py, an external application-policy consumer, not vendored Core.',
 'tools/v2/mutations.py':'src/v2/composition.py in the disposable fresh worktree; finally restores original bytes.',
 'tools/v2/validate_survivors.py':'src/v2/composition.py in the disposable fresh worktree; finally restores original bytes.',
 'tools/v3/mutations.py':'src/v3/model.py in the disposable fresh worktree; finally restores original bytes.',
 'tools/v4/mutations.py':'src/v4/model.py and fixtures/v4/catalog.json in disposable fresh worktree; finally restores both.',
 'tools/v4_1/mutations.py':'src/v4_1/model.py and fixtures/v4_1/catalog.json in disposable fresh worktree; finally restores both.',
 'tools/integration/mutations.py':'Build output copies of src/integration/engine.py; worker modules compiled from those copies.',
 'experiments/verdict_escrow/mutations.py':'Build output copies of the separate escrow adapter; no Core edit.',
 'experiments/verdict_escrow/onchain_mutations.py':'Build output Solidity laboratory harness and isolated escrow source variants.',
 'tools/pr12_pr13_integration/controls.py':'Short temporary full copy; six explicit non-Core historical/policy input tamper sites with inventory resealing and restoration.',
}
rows={}
for path,scope in reviewed.items():
 raw=(ROOT/'fresh'/path).read_bytes()
 pinned=subprocess.check_output(['git','show','5ebabe818173ffdb87dd9018d60c43ed77002c1a:'+path],cwd=ROOT/'fresh')
 if raw!=pinned:raise ValueError('review source mismatch: '+path)
 rows[path]={'sha256':hashlib.sha256(raw).hexdigest(),'inspected_write_scope':scope,'method':'same-executor source inspection; not a formal static analysis proof'}
result={'schema':'veca-mutation-scope-review-v1','source_commit':'5ebabe818173ffdb87dd9018d60c43ed77002c1a','files':rows,
 'core_mutation_authorized':False,'core_write_target_found':False,
 'core_temporary_copies':'Unmodified byte copies of pinned Core are used by inherited consumer mutation harnesses, not alternative implementations.',
 'execution_observations':'Separate command receipts and pre/post Git-object audits are required; this document alone does not prove execution or restoration.'}
(ROOT/'MUTATION_SCOPE_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'reviewed_mutation_runners':len(rows),'core_write_target_found':False}))
