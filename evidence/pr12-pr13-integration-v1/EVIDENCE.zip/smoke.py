import importlib.util,json
from pathlib import Path
s=importlib.util.spec_from_file_location('baselines',Path(__file__).with_name('baselines.py'));b=importlib.util.module_from_spec(s);s.loader.exec_module(b);r=b.r
root=b.prepare('integration')
inventory=json.loads((root/'artifacts.sha256.json').read_bytes())
for p in ('tools/pr12_pr13_integration/runtime_binding.py',):inventory['files'][p]=r.sha((root/p).read_bytes())
r.save(root/'artifacts.sha256.json',inventory)
for name,args in [('package',['tools/erc8004_fuzz/package.py','--extract']),('fuzz-policy',['tools/pr12_pr13_integration/preservation.py','--fuzz']),('spec',['tools/pr12_pr13_integration/spec_validate.py','--out','build/integration-smoke/spec']),('runtime',['tools/pr12_pr13_integration/runtime_binding.py','--out','build/integration-smoke/core-binding'])]:
 r.run('integration-smoke-'+name,[r.PY,'-B',*args],root,allow=True)
