"""Generate only the enumerated new integration layer; never reseal old pins."""
import importlib.util,json,hashlib,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'integration'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=ROOT)
def write(path,raw):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw.encode() if isinstance(raw,str) else raw)
def encode(v):return json.dumps(v,sort_keys=True,indent=2)+'\n'
s=importlib.util.spec_from_file_location('policy',ROOT/'tools/pr12_pr13_integration/preservation.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
pins={ref:sha(git(ref,'artifacts.sha256.json')) for ref in (p.BASE,p.MAIN,p.PR12,p.PR13)}
base=json.loads(git(p.BASE,'artifacts.sha256.json'))['files'];main=json.loads(git(p.MAIN,'artifacts.sha256.json'))['files']
policy={'schema':'veca-pr12-pr13-preservation-transition-v1','source_manifest_sha256':pins,
        'core_changes_permitted':False,'new_files':list(p.NEW_FILES),
        'transitions':{n:{'before_sha256':base[n],'after_sha256':main[n],
             'review_commit':'4799a7260d8f99e489541cffe471e53c50411459' if n.endswith('integrity.py') else 'e5263f47325a81b0647f3de3a7bc36ad858aea5a'} for n in p.TRANSITIONS},
        'workflow_substitutions':{n:[{'before':a.decode(),'after':b.decode()} for a,b in rows] for n,rows in p.WORKFLOWS.items()},
        'historical_contract_results':'Old checks remain frozen; their exact refusal is expected on main composition. No refusal is relabelled a conformance PASS.',
        'core_policy':'All main entries remain unchanged. No ERC8404 Core, baseline, dependency, vector, pin, field, status or preimage transition exists.'}
raw=encode(policy);write(p.POLICY,raw)
source=(ROOT/'tools/pr12_pr13_integration/preservation.py').read_text()
source=source.replace("'GENERATED_EXACT_POLICY_PIN'",repr(sha(raw.encode())))
source=source.replace('{}  # GENERATED_EXACT_MANIFEST_PINS',repr(pins))
write('tools/pr12_pr13_integration/preservation.py',source)
for path,changes in p.WORKFLOWS.items():
 raw=git(p.PR13,path)
 for before,after in changes:
  if raw.count(before)!=1:raise ValueError('workflow occurrence')
  raw=raw.replace(before,after)
 write(path,raw)
raw=git(p.PR12,'tools/erc8004_fuzz/validate.py').decode()
raw=raw.replace('"""Fresh real-EVM replay, with setup/check failures kept separate from success."""','"""Integration v1 orchestration; unchanged PR12 engine/oracle and explicit preservation."""')
raw=raw.replace("['tools/erc8004_fuzz/integrity.py']","['tools/pr12_pr13_integration/preservation.py', '--fuzz']")
raw=raw.replace("    # Execute the original pilot", "    run('six-physical-mutations-optimized', ['tools/erc8004_fuzz/mutations.py', '--out', str(out / 'mutations-optimized')], True)\n    # Execute the original pilot")
raw=raw.replace("    h.write(out / 'summary.json', result)","    extra = json.loads((out / 'mutations-optimized/report.json').read_bytes())\n    if extra['counts'] != {'KILLED': 6} or not extra['original_source_unchanged']:\n        raise ValueError('optimized physical mutation failure')\n    result.update(integration_profile='veca-pr12-pr13-integration-v1', optimized_mutations=extra['counts'], independent_review='NOT_ESTABLISHED')\n    h.write(out / 'summary.json', result)")
write('tools/pr12_pr13_integration/fuzz_validate.py',raw)
raw=git(p.PR13,'tools/spec_drift_coverage/validate.py').decode()
raw=raw.replace('"""Execute offline research controls and preserve actual command receipts."""','"""Integration v1: unchanged semantic reporter, explicit versioned preservation control."""')
raw=raw.replace("['tools/spec_drift_coverage/integrity.py']","['tools/pr12_pr13_integration/preservation.py']")
raw=raw.replace("['-m','unittest','discover','-s','tests/spec_drift_coverage','-v']","['tools/pr12_pr13_integration/spec_controls.py']")
raw=raw.replace("[('normal',False),('optimized',True)]","[('normal',False),('repeat',False),('optimized',True)]")
raw=raw.replace("['tools/spec_drift_coverage/coverage.py',","['tools/pr12_pr13_integration/spec_cli.py','coverage',")
raw=raw.replace("['tools/spec_drift_coverage/drift.py',","['tools/pr12_pr13_integration/spec_cli.py','drift',")
raw=raw.replace("'schema':'veca.spec-drift-validation.v0'","'schema':'veca.spec-drift-integration-validation.v1','control_population':'31 unchanged semantic controls + 1 explicit preservation transition control; original 32 on PR13 baseline'")
write('tools/pr12_pr13_integration/spec_validate.py',raw)
readme='''# PR12 / PR13 integration v1

Local research candidate on main 999e7047df15585f8ce0629081a1369a4942353f.
Production HOLD. No claim of independent human review.

The two merge commits preserve PR ancestry. Original research sources, source
locks, evidence, reports and initial manifests remain byte-identical. Only the
two new workflows select explicitly versioned integration entrypoints. Their
original bytes remain authenticated at the PR13 Git object and in original seals.

TRANSITION.json binds three already-reviewed main differences outside Core and
exact workflow substitutions. preservation.py pins its raw SHA256 and all four
historical inventory hashes. No Core transition is permitted. The inventory
addition scope is an exact file list, including this report and the new archive.
Historical manifests are not regenerated. New evidence is identified separately.

PR13's original preservation test is intentionally incompatible with main.
The original 32 controls run at its exact SHA. The integrated suite runs 31
unchanged semantic tests plus a versioned preservation test that requires both
the old checker's exact refusal and the new contract's acceptance. The old test
and checker remain untouched. This population distinction is reported explicitly.
The integrated semantic reporter and drift classifier call the unchanged APIs.

## Replay

Use full Git history, Python 3.12 and Node 22.15.0. Prepare dependencies:

```sh
python -B tools/agent_harness.py prepare
python -B tools/erc8004/prepare.py
python -B research/formal-v1/prepare_crypto.py
npm ci --ignore-scripts --no-audit --no-fund --prefix build/formal-v1/crypto
python -B tools/pr12_pr13_integration/preservation.py
python -B tools/pr12_pr13_integration/fuzz_validate.py --out build/property-replay
python -B tools/pr12_pr13_integration/spec_validate.py --out build/spec-drift-coverage/validation
python -B tools/pr12_pr13_integration/runtime_binding.py --out build/core-runtime-binding
python -B tools/pr12_pr13_integration/controls.py --out build/preservation-controls
python -B tools/pr12_pr13_integration/spec_cli.py drift --live --out build/spec-drift-live
```

Run mutation campaigns serially. The six Solidity mutants modify disposable
ERC8004 implementation copies only. External ERC8404 consumer mutations never
modify Core. No Core adapter/schema/vector/preimage/pin is changed or regenerated.

See REPORT.md for actual executions and evidence/pr12-pr13-integration-v1 for
the separately sealed evidence. Archive presence alone is not an execution proof.
'''
write('research/pr12-pr13-integration-v1/README.md',readme)
write('research/pr12-pr13-integration-v1/REPORT.md','# Integration execution report\n\nValidation in progress. No success claim yet. Production HOLD.\n')
write('evidence/pr12-pr13-integration-v1/README.md','# Newly executed integration evidence\n\nThis directory is separate from frozen historical evidence. Final receipts and archive will be sealed after actual replay.\n')
write('evidence/pr12-pr13-integration-v1/RESULTS.json',encode({'state':'NOT_RUN','production':'HOLD'}))
with zipfile.ZipFile(ROOT/'evidence/pr12-pr13-integration-v1/EVIDENCE.zip','w'):pass
write('evidence/pr12-pr13-integration-v1/SHA256.json',encode({'state':'NOT_RUN','members':{}}))
inventory=json.loads((ROOT/'artifacts.sha256.json').read_bytes())
for name in (*p.WORKFLOWS,*p.NEW_FILES):inventory['files'][name]=sha((ROOT/name).read_bytes())
write('artifacts.sha256.json',encode(inventory))
print('Prepared exact new files and workflow transitions; historical bytes untouched')
