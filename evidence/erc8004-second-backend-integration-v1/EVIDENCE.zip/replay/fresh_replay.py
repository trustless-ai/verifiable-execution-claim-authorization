from run import *
import importlib.util
source=ROOT/'repo';fresh=ROOT/'fresh'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
run('fresh-clone',['git','-c','core.autocrlf=false','clone','--no-hardlinks','--no-checkout',source,fresh],ROOT)
run('fresh-pin',['git','-C',fresh,'-c','core.autocrlf=false','checkout','--detach',head],ROOT)
run('fresh-views',[PY,'-B','tools/second_backend_integration/replay.py','prepare'],fresh)
run('fresh-new-prepare',[PY,ROOT/'prepare_runtime.py',fresh,'fresh-current','new'],ROOT)
for mode,flags in [('normal',[]),('optimized',['-O'])]:
    run('fresh-transition-tests-'+mode,[PY,'-B',*flags,'-m','unittest','discover','-s','tests/second_backend_integration','-v'],fresh)
    run('fresh-old-documentation-tests-'+mode,[PY,'-B',*flags,'-m','unittest','discover','-s','tests/documentation_refresh','-v'],fresh/'build/base15')
run('fresh-current-new-campaign',[PY,'-B','tools/second_backend_integration/ci.py','--prepared'],fresh)
run('fresh-core-python',[PY,'-B','evidence/erc8404/core/conformance/rvr-v0/adapter.py','--check'],fresh)
run('fresh-core-python-optimized',[PY,'-B','-O','evidence/erc8404/core/conformance/rvr-v0/adapter.py','--check'],fresh)
run('fresh-core-typescript',['C:/Users/msi/.bun/bin/bun.exe','evidence/erc8404/core/conformance/rvr-v0/adapter.ts','--check'],fresh)
run('fresh-workflow-audit',['C:/Users/msi/.bun/bin/bun.exe',ROOT/'workflow_audit.mjs',fresh],ROOT)
run('fresh-end-inventory',[PY,'-B','tools/verify_artifacts.py'],fresh)
run('fresh-end-transition',[PY,'-B','tools/second_backend_integration/replay.py','check'],fresh)
if subprocess.check_output(['git','status','--porcelain'],cwd=fresh):raise ValueError('fresh checkout changed')
save(ROOT/'FRESH_NEW_DONE.json',{'passed':True,'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=fresh,text=True).strip(),'working_tree_clean':True,'independence':'same Codex executor; clean ordinary clone, not independent review'})
print('FRESH_NEW_DONE',head,flush=True)
