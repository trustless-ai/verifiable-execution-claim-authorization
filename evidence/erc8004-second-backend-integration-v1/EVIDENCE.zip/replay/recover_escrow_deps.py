from run import *
short=Path('D:/vca-escrow-1120');pin='4b6d7ef9aabd23932668711ee1d6cf774d9844d7'
previous=json.loads((ROOT/'INHERITED_CLOSURE.json').read_bytes())
if previous['passed'] or subprocess.check_output(['git','rev-parse','HEAD'],cwd=short,text=True).strip()!=pin:raise ValueError('unexpected recovery state')
run('escrow-short-crypto-install',['C:/Program Files/nodejs/npm.cmd','ci','--ignore-scripts','--no-audit','--no-fund','--prefix','build/formal-v1/crypto'],short)
probe="import sys,json; sys.path.insert(0,'experiments/verdict_escrow'); import vectors; v=vectors.make('positive'); result={'record_status':v['record']['status'],'authorized':v['adapter']['authorized'],'adapter_status':v['adapter']['status']}; print(json.dumps(result)); raise SystemExit(0 if result=={'record_status':'VERIFIED','authorized':True,'adapter_status':'VERIFIED'} else 1)"
run('escrow-short-positive-preflight',[PY,'-B','-c',probe],short)
result=run('inherited-historical-escrow-complete-setup',[PY,'-B','-X','utf8','tools/escrow_ci.py','--out','build/escrow/ci-ready'],short,allow=True,env={'RUSTUP_TOOLCHAIN':'1.97.1','FORGE':'C:/Users/msi/.foundry/bin/forge.exe'})
clean=subprocess.check_output(['git','status','--porcelain'],cwd=short)==b''
save(ROOT/'INHERITED_FINAL.json',{
    'passed':result['exit_code']==0 and clean,
    'source_commit':pin,'short_worktree':str(short),'working_tree_clean':clean,
    'earlier_aggregates':{n:sha((ROOT/n).read_bytes()) for n in ('INHERITED_DONE.json','INHERITED_RESOLVED.json','INHERITED_CLOSURE.json')},
    'failed_attempts':['inherited-historical-escrow','inherited-historical-escrow-correct-output','inherited-historical-escrow-short-path'],
    'diagnoses':['Initial output outside frozen Foundry write permissions.','Allowed-path retry passed all 28 validation commands but Windows long-path disposable copy failed.','Short checkout offline prepare omitted npm ci; missing crypto dependencies correctly prevented positive authorization.'],
    'resolution':'Installed existing locked crypto dependencies, executed positive preflight, then full unchanged escrow_ci.py in short detached historical worktree.',
    'corrected_command_receipt':'logs/inherited-historical-escrow-complete-setup.json',
    'corrected_exit_code':result['exit_code'],'source_or_config_changes':False,'original_evidence_preserved':True,
})
if result['exit_code'] or not clean:raise RuntimeError('complete-setup escrow did not close')
print('INHERITED_FINAL PASS',flush=True)
