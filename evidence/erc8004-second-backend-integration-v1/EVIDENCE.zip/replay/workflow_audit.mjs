import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=path.resolve(process.argv[2]||'repo');
const base='29155372c6a16f23d1bc2091f2f3671c51e0da4c';
const get=name=>execFileSync('git',['show',base+':'+name],{cwd:root,encoding:'utf8'});
const oldFiles=execFileSync('git',['ls-tree','-r','--name-only',base,'.github/workflows'],{cwd:root,encoding:'utf8'}).trim().split('\n');
function canon(o){return JSON.stringify(o,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort()):v);}
function normalize(o,isNew,isDoc){
  o=structuredClone(o);
  for(const job of Object.values(o.jobs)){
    if(isNew&&isDoc)delete job.defaults;
    if(isNew&&job.defaults?.run?.['working-directory'])job.defaults.run['working-directory']=job.defaults.run['working-directory'].replace(/^build\/base15\//,'');
    if(isNew&&isDoc)job.steps=job.steps.filter(s=>!s.run?.includes('tools/second_backend_integration/replay.py'));
    for(const step of job.steps){
      if(isNew&&step.run&&!isDoc)step.run=step.run.replaceAll('tools/second_backend_integration/replay.py','tools/documentation_refresh/replay.py');
      if(isNew&&step['working-directory'])step['working-directory']=step['working-directory'].replace(/^build\/base15\//,'');
      if(step.uses?.startsWith('actions/upload-artifact@')&&typeof step.with.path==='string'){
        let lines=step.with.path.trim().split('\n');
        if(isNew)lines=lines.filter(s=>s!=='build/second-backend-integration/REPLAY.json').map(s=>s.replace(/^build\/base15\//,''));
        step.with.path=lines.join('\n');
      }
    }
  }
  return o;
}
const rows=[];
for(const name of oldFiles){
  const a=get(name),b=fs.readFileSync(path.join(root,name),'utf8');
  const old=Bun.YAML.parse(a),now=Bun.YAML.parse(b),isDoc=name.endsWith('/documentation-refresh.yml');
  const equal=canon(normalize(old,false,isDoc))===canon(normalize(now,true,isDoc));
  rows.push({path:name,byte_identical:a===b,semantic_settings_and_commands_equal:equal});
  if(!equal)throw Error('workflow semantic drift '+name);
}
const added=Bun.YAML.parse(fs.readFileSync(path.join(root,'.github/workflows/erc8004-second-backend.yml'),'utf8'));
const job=added.jobs['pinned-second-backend'];
if(job['runs-on']!=='windows-latest'||job.steps.find(s=>s.uses?.startsWith('actions/setup-python@'))?.with['python-version']!=='3.12.10'||!job.steps.some(s=>s.run==='python -B tools/second_backend_integration/ci.py'))throw Error('new workflow contract');
console.log(JSON.stringify({passed:true,inherited:rows.length,byte_identical:rows.filter(r=>r.byte_identical).length,routing_only:rows.filter(r=>!r.byte_identical).length,new_workflows:1,rows},null,2));
