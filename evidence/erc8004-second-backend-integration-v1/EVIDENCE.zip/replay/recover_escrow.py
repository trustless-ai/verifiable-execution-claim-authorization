from run import *
import time

while not (ROOT/'INHERITED_DONE.json').exists():
    time.sleep(5)
original=json.loads((ROOT/'INHERITED_DONE.json').read_bytes())
failed=[r for r in original['commands'] if r['exit_code']]
if len(failed)!=1 or failed[0]['label']!='historical-escrow':
    raise ValueError('unexpected campaign failures; inspect before recovery')
inner=ROOT/'fresh/build/base15/build/documentation-replay'
result=run('inherited-historical-escrow-correct-output',[
    PY,'-B','-X','utf8','tools/escrow_ci.py','--out','build/escrow/integration-replay'],
    inner,allow=True,env={'RUSTUP_TOOLCHAIN':'1.97.1','FORGE':'C:/Users/msi/.foundry/bin/forge.exe'})
resolution={
    'passed':result['exit_code']==0,
    'original_campaign_sha256':sha((ROOT/'INHERITED_DONE.json').read_bytes()),
    'original_command_failures':failed,
    'diagnosis':'Audit orchestration selected build/inherited/escrow; immutable Foundry fs_permissions permits writes only under build/escrow. First EVM run rejected vm.writeJson outside that path. This is neither a semantic mismatch nor a mutation kill.',
    'source_or_config_changes':False,
    'corrected_output':'build/escrow/integration-replay',
    'corrected_command_receipt':'logs/inherited-historical-escrow-correct-output.json',
    'corrected_exit_code':result['exit_code'],
    'original_evidence_preserved':True,
    'original_commands':original['commands'],
}
save(ROOT/'INHERITED_RESOLVED.json',resolution)
if not resolution['passed']:raise RuntimeError('escrow corrected-path replay failed')
print('INHERITED_RESOLVED PASS',flush=True)
