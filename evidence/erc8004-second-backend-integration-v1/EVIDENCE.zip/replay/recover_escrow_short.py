from run import *

short=Path('D:/vca-escrow-1120')
pin='4b6d7ef9aabd23932668711ee1d6cf774d9844d7'
if short.exists():raise ValueError('short worktree already exists; do not overwrite')
previous=json.loads((ROOT/'INHERITED_RESOLVED.json').read_bytes())
if previous['passed']:raise ValueError('no unresolved failure')
run('escrow-short-worktree',['git','-c','core.autocrlf=false','worktree','add','--detach',short,pin],ROOT/'fresh')
run('escrow-short-native-prepare',[PY,'-B',ROOT/'prepare_runtime.py',short,'escrow-short-native','native'],ROOT)
run('escrow-short-prepare',[PY,'-B',ROOT/'prepare_runtime.py',short,'escrow-short','escrow'],ROOT)
result=run('inherited-historical-escrow-short-path',[PY,'-B','-X','utf8','tools/escrow_ci.py','--out','build/escrow/ci'],short,allow=True,env={'RUSTUP_TOOLCHAIN':'1.97.1','FORGE':'C:/Users/msi/.foundry/bin/forge.exe'})
clean=subprocess.check_output(['git','status','--porcelain'],cwd=short)==b''
identity=subprocess.check_output(['git','rev-parse','HEAD'],cwd=short,text=True).strip()
save(ROOT/'INHERITED_CLOSURE.json',{
    'passed':result['exit_code']==0 and clean and identity==pin,
    'source_commit':identity,'short_worktree':str(short),'working_tree_clean':clean,
    'original_campaign_sha256':sha((ROOT/'INHERITED_DONE.json').read_bytes()),
    'first_retry_sha256':sha((ROOT/'INHERITED_RESOLVED.json').read_bytes()),
    'failed_attempts':['inherited-historical-escrow','inherited-historical-escrow-correct-output'],
    'diagnoses':['Initial audit output was outside frozen Foundry fs_permissions.',
                 'Allowed-path retry passed all 28 escrow validation commands, then Windows failed a disposable-copy file creation at a path longer than MAX_PATH.'],
    'resolution':'Fresh detached short-path worktree of identical frozen source; pinned dependencies prepared again; complete unchanged escrow_ci.py executed, not a synthesized PASS.',
    'corrected_command_receipt':'logs/inherited-historical-escrow-short-path.json',
    'corrected_exit_code':result['exit_code'],'source_or_config_changes':False,
    'original_evidence_preserved':True,
})
if result['exit_code'] or not clean or identity!=pin:raise RuntimeError('short-path escrow recovery did not close')
print('INHERITED_CLOSURE PASS',flush=True)
