from run import *
import re
from collections import Counter
fresh=ROOT/'fresh';inner=fresh/'build/base15/build/documentation-replay'
def read(p):return json.loads(Path(p).read_bytes())
def main():
    for marker in ('FRESH_NEW_DONE.json','INHERITED_FINAL.json','VIEW_CONTROLS.json','OLD_CONTRACTS.json','SOURCE_AUDIT.json'):
        if not read(ROOT/marker)['passed']:raise ValueError('incomplete closure '+marker)
    suites={}
    def add(label,p,scope):
        data=read(p)
        suites[label]={'scope':scope,'path':str(p),'sha256':sha(Path(p).read_bytes()),'summary':{k:v for k,v in data.items() if k not in ('commands','runs','environment','source_inventory','platform','python','node','working_tree_status')}}
    add('second-backend',fresh/'build/second-backend-integration/campaign/RESULTS.json','current')
    optimization={}
    for mode in ('normal','repeat','optimized'):
        optimization[mode]={}
        for backend in ('solidity','vyper'):
            argv=read(fresh/('build/second-backend-integration/campaign/'+mode+'/'+backend+'/report.json'))['adapter_argv']
            if ('-O' in argv)!=(mode=='optimized'):raise ValueError('adapter optimization propagation')
            optimization[mode][backend]=argv
    for name in ('v0','formal','v2','v2-survivors','v3','v4','core-consumer','v0-py313'):
        add(name,fresh/'build/inherited'/name/'report.json','current')
    for name,file in [('fuzz','summary.json'),('spec','SUMMARY.json'),('harness','summary.json'),('supplement','summary.json'),('role-v1','summary.json'),('role-v2','summary.json'),('claim-integration','report.json'),('escrow','report.json'),('core-binding','RESULTS.json'),('old-preservation','RESULTS.json'),('live-drift','SOURCE_DRIFT.json')]:
        path=inner/'build/inherited'/name/file
        if name=='escrow':path=Path('D:/vca-escrow-1120/build/escrow/ci-ready/report.json')
        # Old preservation names its output REPORT.json; use exact observed file.
        if name=='old-preservation' and not path.exists():
            candidates=[p for p in path.parent.glob('*.json') if p.name.lower() in ('report.json','results.json')]
            if len(candidates)!=1:raise ValueError('ambiguous preservation output')
            path=candidates[0]
        add(name,path,'historical4b6-newly-executed')
    add('v4.1-comparison',ROOT/'logs/inherited-historical-v4_1-run.stdout','historical4b6-newly-executed')
    executed_v41={}
    for mode in ('','-O'):
        folder=inner/('build/inherited/v4_1-mutations'+mode)
        add('v4.1-mutations'+mode,folder/'report.json','historical4b6-newly-executed')
        executions=read(folder/'executions.json')
        if len(executions)!=54:raise ValueError('v4.1 actual execution population failure')
        for execution in executions:
            raw=(folder/(execution['mutation']+'.'+execution['phase']+'.stdout.log')).read_bytes()
            observation=json.loads(raw)
            if (execution['exit'] not in (0,1) or sha(raw)!=execution['stdout_sha256'] or
                observation['schema']!='v4.1-comparison' or type(observation['passed']) is not bool or
                (execution['exit']==0)!=observation['passed']):raise ValueError('v4.1 crash/timeout or inconsistent semantic exit')
        executed_v41[mode or 'normal']={'executions':len(executions),'only_determinate_semantic_exits':True,'exit_counts':dict(Counter(str(r['exit']) for r in executions)),'sha256':sha((folder/'executions.json').read_bytes())}
    counts={}
    for path in sorted((ROOT/'logs').glob('*.stderr')):
        found=re.findall(rb'Ran (\d+) tests',path.read_bytes())
        if found:counts[path.stem]=list(map(int,found))
    commands={p.stem:read(p) for p in sorted((ROOT/'logs').glob('*.json'))}
    failed={name:r for name,r in commands.items() if r.get('exit_code',0)!=0}
    expected={'pilot-original-preservation-current-refusal','documentation-original-current-refusal'}
    resolved={'inherited-historical-escrow','inherited-historical-escrow-correct-output','inherited-historical-escrow-short-path'}
    if set(failed)!=expected|resolved:raise ValueError('unexpected failed outer command '+str(set(failed)^(expected|resolved)))
    result={'schema':'veca-second-backend-integration-executed-v1','passed':True,'source_commit':read(ROOT/'SOURCE_AUDIT.json')['source_commit'],'source_tree':read(ROOT/'SOURCE_AUDIT.json')['source_tree'],'execution_scope':'current candidate plus separately identified immutable historical views','executor':'OpenAI Codex, same executor; no independent human review','local_platform':read(ROOT/'ENVIRONMENT.json'),'suites':suites,'outer_unittest_counts':counts,'outer_command_count':len(commands),'expected_old_contract_refusals':sorted(expected),'unexpected_command_failures':sorted(resolved),'unresolved_command_failures':[],'candidate_github_actions':'NOT_RUN','main_github_actions':read(ROOT/'MAIN_CI.json'),'production':'HOLD'}
    result['aggregation_observed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['latest_remote_observation']=read(ROOT/'FINAL_REMOTE.json')
    if not result['latest_remote_observation']['unchanged']:raise ValueError('main moved during replay')
    result['resolved_orchestration_failures']=read(ROOT/'INHERITED_FINAL.json')
    result['actual_adapter_optimization_argv']=optimization
    result['v4_1_actual_execution_audit']=executed_v41
    result['outer_command_labels']=sorted(commands)
    result['command_count_scope']='Completed command receipts present at aggregation; later packaging/closure receipts are separate.'
    save(ROOT/'EXECUTION_SUMMARY.json',result)
    print(json.dumps({'passed':True,'suite_labels':list(suites),'outer_unittest_counts':counts,'outer_commands':len(commands)},indent=2))
if __name__=='__main__':main()
