from run import *
BASE='29155372c6a16f23d1bc2091f2f3671c51e0da4c'
SOURCE='169fe90d81c94919ccc3eac4c218d69c1c685f8f'
PILOT='1ce2b4e0f3e83faf1a16d5ced0507aca20e4ba90'
repo=ROOT/'repo';fresh=ROOT/'fresh'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def tree(ref):
    out={}
    for raw in git(repo,'ls-tree','-rz',ref).split(b'\0'):
        if not raw:continue
        meta,name=raw.split(b'\t',1);mode,kind,oid=meta.split()
        if kind!=b'blob' or mode not in (b'100644',b'100755'):raise ValueError('unexpected tree entry')
        out[name.decode()]={'blob':oid.decode(),'mode':mode.decode()}
    return out
def audit():
    for root in (repo,fresh):
        if git(root,'rev-parse','HEAD').decode().strip()!=SOURCE or git(root,'status','--porcelain'):raise ValueError('source not clean')
    if git(repo,'rev-parse','--show-object-format').strip()!=b'sha1':raise ValueError('unsupported Git object format')
    baseline=tree(BASE);source=tree(SOURCE);pilot=tree(PILOT)
    changed=sorted(p for p in baseline if source.get(p)!=baseline[p]);added=sorted(set(source)-set(baseline))
    policy=json.loads((repo/'research/erc8004-second-backend-integration-v1/TRANSITION.json').read_bytes())
    if changed!=sorted(['README.md','artifacts.sha256.json',*policy['workflows']]):raise ValueError('unexpected baseline change')
    if added!=sorted([*policy['pilot_files'],*policy['new_files']]):raise ValueError('unexpected addition')
    for p in policy['pilot_files']:
        if source[p]!=pilot[p]:raise ValueError('pilot Git bytes changed')
    protected=sorted(p for p in baseline if 'erc8404' in p.lower())
    if any(source[p]!=baseline[p] for p in protected):raise ValueError('Core Git byte change')
    rows={}
    for name,entry in source.items():
        a=(repo/name).read_bytes();b=(fresh/name).read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest()
        if a!=b or blob!=entry['blob']:raise ValueError('executed filesystem mismatch '+name)
        rows[name]={'git_blob':blob,'sha256':sha(a),'bytes':len(a)}
    shallow={str(root):git(root,'rev-parse','--is-shallow-repository').decode().strip() for root in (repo,fresh)}
    if set(shallow.values())!={'false'}:raise ValueError('full history required')
    short=Path('D:/vca-escrow-1120');short_pin='4b6d7ef9aabd23932668711ee1d6cf774d9844d7'
    if git(short,'rev-parse','HEAD').decode().strip()!=short_pin or git(short,'status','--porcelain'):raise ValueError('short historical worktree identity')
    short_tree=tree(short_pin);short_rows={}
    for name,entry in short_tree.items():
        raw=(short/name).read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if blob!=entry['blob']:raise ValueError('short historical bytes '+name)
        short_rows[name]={'git_blob':blob,'sha256':sha(raw),'bytes':len(raw)}
    result={'passed':True,'source_commit':SOURCE,'source_tree':git(repo,'rev-parse',SOURCE+'^{tree}').decode().strip(),'branch':git(repo,'branch','--show-current').decode().strip(),'base':BASE,'pilot':PILOT,'merge_commit':'0d426315700d43fa3b88ae19cc04156decdbebe5','merge_parents':git(repo,'show','-s','--format=%P','0d426315700d43fa3b88ae19cc04156decdbebe5').decode().strip().split(),'shallow_repositories':shallow,'changed_baseline_files':changed,'added_files':added,'baseline_files_unchanged':len(baseline)-len(changed),'pilot_files_exact':len(policy['pilot_files']),'protected_Core_related_files':len(protected),'current_and_fresh_files_exact':len(rows),'files':rows,'independence':'same executor; Git-object and filesystem comparison, not human review'}
    result['short_historical_view']={'path':str(short),'head':short_pin,'files_exact':len(short_rows),'files':short_rows,'working_tree_clean':True}
    save(ROOT/'SOURCE_AUDIT.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('files','short_historical_view')}))
if __name__=='__main__':audit()
