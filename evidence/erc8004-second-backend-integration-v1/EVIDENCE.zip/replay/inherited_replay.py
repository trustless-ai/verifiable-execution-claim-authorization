from run import *
import time
deadline=time.monotonic()+7200
for marker in ('FRESH_NEW_DONE.json','INHERITED_PREPARED.json'):
    while not (ROOT/marker).exists():
        if time.monotonic()>deadline:raise RuntimeError('required preparation/replay did not complete')
        time.sleep(5)
    if not json.loads((ROOT/marker).read_bytes())['passed']:raise RuntimeError('prior campaign failed')
fresh=ROOT/'fresh';inner=fresh/'build/base15/build/documentation-replay';plan=[]
def job(label,root,args):plan.append((label,root,args))
# Current-root jobs corresponding to the six byte-frozen workflows.
for label,args in [
    ('v0',['tools/validate.py','--out','build/inherited/v0']),
    ('formal',['research/formal-v1/validate.py','--out','build/inherited/formal']),
    ('v2-statement',['tools/v2/statement.py']),
    ('v2',['tools/v2/validate.py','--out','build/inherited/v2']),
    ('v2-snapshot',['tools/v2/check_snapshot.py','--out','build/inherited/v2']),
    ('v2-survivors',['tools/v2/validate_survivors.py','--out','build/inherited/v2-survivors']),
    ('v3',['tools/v3/validate.py','--out','build/inherited/v3']),
    ('v4',['tools/v4/validate.py','--out','build/inherited/v4']),
    ('core-consumer',['tools/erc8404/validate.py','--out','build/inherited/core-consumer']),
    ('core-benchmark',['tools/erc8404/benchmark.py']),
]:job('current-'+label,fresh,args)
# Each physical mutation campaign executes serially, on the checked old source tree.
for label,args in [
    ('fuzz',['tools/pr12_pr13_integration/fuzz_validate.py','--out','build/inherited/fuzz']),
    ('spec',['tools/pr12_pr13_integration/spec_validate.py','--out','build/inherited/spec']),
    ('harness',['tools/harness_v0/validate.py','--out','build/inherited/harness']),
    ('harness-supplement',['tools/harness_v0/review_validate.py','--out','build/inherited/supplement']),
    ('role-v1',['tools/erc8004_role_policy/validate.py','--out','build/inherited/role-v1']),
    ('role-v2',['tools/erc8004_role_policy_v2/validate.py','--out','build/inherited/role-v2']),
    ('v4_1-run',['tools/v4_1/run.py']),
    ('v4_1-tests',['-m','unittest','-v','tests.v4_1.test_v4_1']),
    ('v4_1-tests-O',['-O','-m','unittest','-v','tests.v4_1.test_v4_1']),
    ('v4_1-mutations',['tools/v4_1/mutations.py','--out','build/inherited/v4_1-mutations']),
    ('v4_1-mutations-O',['-O','tools/v4_1/mutations.py','--out','build/inherited/v4_1-mutations-O']),
    ('claim-integration',['tools/integration/validate.py','--out','build/inherited/claim-integration']),
    ('escrow',['-X','utf8','tools/escrow_ci.py','--out','build/inherited/escrow']),
    ('runtime-core-binding',['tools/pr12_pr13_integration/runtime_binding.py','--out','build/inherited/core-binding']),
    ('old-preservation-controls',['tools/pr12_pr13_integration/controls.py','--out','build/inherited/old-preservation']),
    ('live-drift',['tools/pr12_pr13_integration/spec_cli.py','drift','--live','--out','build/inherited/live-drift']),
]:job('historical-'+label,inner,args)
for tests in ('baseline_reconciliation','erc8004_role_policy','erc8004_role_policy_v2','harness_review'):
    for mode,flags in [('normal',[]),('optimized',['-O'])]:job('historical-tests-'+tests+'-'+mode,inner,[*flags,'-m','unittest','discover','-s','tests/'+tests,'-v'])
results=[]
for label,root,args in plan:
    r=run('inherited-'+label,[PY,'-B',*args],root,allow=True,env={'RUSTUP_TOOLCHAIN':'1.97.1','FORGE':'C:/Users/msi/.foundry/bin/forge.exe'})
    results.append({'label':label,'root':str(root),'exit_code':r['exit_code']});save(ROOT/'INHERITED_PROGRESS.json',results)
py313=json.loads(Path('D:/PAVLO HQ/Workspaces/veca-pr12-pr13-integration-v1-20261118/PY313.json').read_bytes())['executable']
r=run('inherited-current-v0-py313',[py313,'-B','tools/validate.py','--out','build/inherited/v0-py313'],fresh,allow=True);results.append({'label':'current-v0-py313','root':str(fresh),'exit_code':r['exit_code']})
for label,root,args in [('current-inventory',fresh,['tools/verify_artifacts.py']),('current-transition',fresh,['tools/second_backend_integration/replay.py','check']),('current-Core',fresh,['tools/erc8404/integrity.py']),('historical-inventory',inner,['tools/verify_artifacts.py']),('historical-preservation',inner,['tools/pr12_pr13_integration/preservation.py','--fuzz'])]:
    r=run('inherited-final-'+label,[PY,'-B',*args],root,allow=True);results.append({'label':label,'root':str(root),'exit_code':r['exit_code']})
save(ROOT/'INHERITED_DONE.json',{'passed':all(r['exit_code']==0 for r in results),'commands':results,'current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=fresh,text=True).strip(),'historical_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=inner,text=True).strip()})
print('INHERITED_DONE',all(r['exit_code']==0 for r in results),flush=True)
