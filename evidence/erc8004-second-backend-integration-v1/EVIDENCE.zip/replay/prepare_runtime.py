from run import *
import shutil
DONOR=Path('D:/PAVLO HQ/Workspaces/veca-pr12-pr13-integration-v1-20261118/fresh')
VYPER=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-second-backend-v0/vyper-source')
def pinned_erc(root,label):
    lock=json.loads((root/'conformance/erc8004-pilot-v0/source-lock.json').read_bytes())
    for kind in ('implementation','specification'):
        entry=lock[kind]
        for name,digest in entry.get('files',{entry.get('path'):entry.get('sha256')}).items():
            raw=(DONOR/'build/erc8004'/kind/name).read_bytes()
            if sha(raw)!=digest:raise ValueError('cache source pin mismatch')
            dest=root/'build/erc8004'/kind/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    run(label+'-grader',[PY,'-B','tools/agent_harness.py','prepare','--source',DONOR/'build/agent-harness-v0/recompute-kit'],root)
    run(label+'-erc8004',[PY,'-B','tools/erc8004/prepare.py'],root)
    run(label+'-crypto',[PY,'-B','research/formal-v1/prepare_crypto.py'],root)
    run(label+'-crypto-install',['C:/Program Files/nodejs/npm.cmd','ci','--ignore-scripts','--no-audit','--no-fund','--prefix','build/formal-v1/crypto'],root)
def native(root,label):
    sources=json.loads((root/'evidence/v3/discovery/sources.json').read_bytes())+[json.loads((root/'evidence/v3/public/ccip-router-source.json').read_bytes())]
    for item in sources:
        if item['repository']=='ethereum/ERCs':continue
        name=item['repository'].split('/')[1];dest=root/'build/v3/upstream'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():run(label+'-clone-'+name,['git','-c','core.autocrlf=false','clone','--no-hardlinks',DONOR/'build/v3/upstream'/name,dest],root)
        run(label+'-pin-'+name,['git','-C',dest,'checkout','--detach',item['commit']],root)
        if subprocess.check_output(['git','status','--porcelain'],cwd=dest):raise ValueError('unclean dependency')
    run(label+'-native',[PY,'-B','tools/v3/prepare.py'],root,env={'RUSTUP_TOOLCHAIN':'1.97.1'})
    run(label+'-python-deps',[PY,'-m','pip','install','--disable-pip-version-check','--no-deps','--require-hashes','--target','build/v3/python-deps','--report','build/v3/python-install.json','-r','research/v3/requirements.lock.txt'],root)
def escrow(root,label):
    dest=root/'build/escrow/forge-std-source';dest.parent.mkdir(parents=True,exist_ok=True)
    run(label+'-forge-source',['git','-c','core.autocrlf=true','clone','--no-checkout','--no-hardlinks',DONOR/'build/escrow/forge-std-source',dest],root)
    run(label+'-forge-pin',['git','-C',dest,'-c','core.autocrlf=true','checkout','--detach','b013eff2ac4fce26f34d789e6f5c49021c5ee817'],root)
    run(label+'-escrow-prepare',[PY,'-B','tools/escrow_prepare.py','--forge-std-cache',dest],root)
if __name__=='__main__':
    root=Path(sys.argv[1]).resolve();label=sys.argv[2];kind=sys.argv[3]
    if kind in ('all','evm','new'):pinned_erc(root,label)
    if kind=='new':run(label+'-vyper',[PY,'-B','tools/erc8004_second_backend/prepare.py','--source',VYPER],root)
    if kind in ('all','native'):native(root,label)
    if kind in ('all','escrow'):escrow(root,label)
