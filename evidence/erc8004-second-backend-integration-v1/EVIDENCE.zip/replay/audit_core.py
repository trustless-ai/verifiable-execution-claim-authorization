from run import *
repo=ROOT/'repo';base='29155372c6a16f23d1bc2091f2f3671c51e0da4c';core='9dd36e882dd372f264b77b179130948aa5adcbde';objects=Path('D:/PAVLO HQ/Workspaces/veca-pr12-pr13-integration-v1-20261118/core-objects')
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def blobs(root,ref,names):
    data=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join(ref+':'+p+'\n' for p in names).encode());pos=0;out={}
    for name in names:
        end=data.index(b'\n',pos);header=data[pos:end].split();size=int(header[2]);pos=end+1;out[name]=(header[0].decode(),data[pos:pos+size]);pos+=size+1
    return out
def audit(label):
    inventory=json.loads(git(repo,'show',base+':artifacts.sha256.json'))['files'];paths=[p for p in inventory if 'erc8404' in p.lower()];baseline=blobs(repo,base,paths);rows={}
    for name,(oid,raw) in baseline.items():
        if sha(raw)!=inventory[name] or (repo/name).read_bytes()!=raw:raise ValueError('Core-protected byte mismatch '+name)
        rows[name]={'git_blob':oid,'sha256':sha(raw)}
    pins=json.loads((repo/'fixtures/erc8404/core-lock.json').read_bytes());tree=json.loads((repo/'evidence/erc8404/upstream-tree-baseline.json').read_bytes());up=blobs(objects,core,list(tree))
    for name,digest in tree.items():
        if sha(up[name][1])!=digest:raise ValueError('upstream Core mismatch '+name)
    if {p.relative_to(repo/'evidence/erc8404/core').as_posix() for p in (repo/'evidence/erc8404/core').rglob('*') if p.is_file()}!=set(pins):raise ValueError('vendored membership')
    for name,digest in pins.items():
        if sha((repo/'evidence/erc8404/core'/name).read_bytes())!=digest or tree[name]!=digest:raise ValueError('vendored mismatch')
    result={'passed':True,'label':label,'base':base,'core_commit':core,'protected_files':rows,'upstream_files':{p:{'sha256':sha(r),'git_blob':oid} for p,(oid,r) in up.items()},'vendored_files':len(pins),'runtime_binding':'SEPARATE_EXECUTION_REQUIRED'}
    save(ROOT/'core-audits'/f'{label}.json',result);print(json.dumps({'passed':True,'protected':len(rows),'upstream':len(tree),'vendored':len(pins)}))
if __name__=='__main__':audit(sys.argv[1])
