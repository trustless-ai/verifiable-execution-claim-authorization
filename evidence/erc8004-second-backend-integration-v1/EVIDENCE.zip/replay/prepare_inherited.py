from run import *
import time
deadline=time.monotonic()+1800
while not (ROOT/'logs/fresh-new-prepare.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('new-runtime preparation wait expired')
    time.sleep(3)
if json.loads((ROOT/'logs/fresh-new-prepare.json').read_bytes())['exit_code']:raise RuntimeError('new-runtime preparation failed')
fresh=ROOT/'fresh';inner=fresh/'build/base15/build/documentation-replay'
run('inherited-current-prepare',[PY,ROOT/'prepare_runtime.py',fresh,'current-native','native'],ROOT)
run('inherited-historical-prepare',[PY,ROOT/'prepare_runtime.py',inner,'historical-all','all'],ROOT)
save(ROOT/'INHERITED_PREPARED.json',{'passed':True,'current':str(fresh),'historical':str(inner)})
print('INHERITED_PREPARED',flush=True)
