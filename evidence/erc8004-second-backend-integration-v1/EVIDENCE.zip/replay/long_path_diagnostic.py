from run import *
import winreg
error=(ROOT/'fresh/build/base15/build/documentation-replay/build/escrow/integration-replay/negative-ci-controls.stderr.log').read_text()
import ast
literal=error.strip().split('No such file or directory: ',1)[1]
path=ast.literal_eval(literal)
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SYSTEM\CurrentControlSet\Control\FileSystem') as key:
    enabled,kind=winreg.QueryValueEx(key,'LongPathsEnabled')
result={'failed_path':path,'path_characters':len(path),'windows_MAX_PATH':260,'LongPathsEnabled':enabled,'registry_access':'READ_ONLY','source_file_exists':(ROOT/'fresh/build/base15/build/documentation-replay/evidence/erc8004-pilot-v0/local-replay/mutations/reject_permitted_updates/baseline/adapter.stderr').is_file(),'config_changed':False,'interpretation':'Destination path exceeded Windows MAX_PATH while system long paths disabled; retry uses shorter real checkout.'}
if len(path)<=260 or enabled!=0:raise ValueError('long-path diagnosis requires further investigation')
save(ROOT/'LONG_PATH_DIAGNOSTIC.json',result);print(json.dumps(result))
