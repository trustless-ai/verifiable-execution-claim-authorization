from run import *
repo=ROOT/'repo';view=ROOT/'pilot-baseline'
pin='1ce2b4e0f3e83faf1a16d5ced0507aca20e4ba90'
run('pilot-baseline-view',['git','-c','core.autocrlf=false','worktree','add','--detach',view,pin],repo)
run('pilot-original-preservation-positive',[PY,'-B','tools/erc8004_second_backend/preservation.py'],view)
r=run('pilot-original-preservation-current-refusal',[PY,'-B','tools/erc8004_second_backend/preservation.py'],repo,allow=True)
body=json.loads((ROOT/'logs/pilot-original-preservation-current-refusal.stdout').read_bytes())
if r['exit_code']!=1 or body['passed'] is not False:raise ValueError('expected exact old pilot refusal')
base='4b6d7ef9aabd23932668711ee1d6cf774d9844d7'
old_files=set(subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=repo,text=True).splitlines())
changed=set(subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=repo,text=True).splitlines())&old_files
if set(body['baseline_changed'])!=changed:raise ValueError('unexplained old baseline refusal')
r=run('documentation-original-current-refusal',[PY,'-B','tools/documentation_refresh/replay.py','check'],repo,allow=True)
document=json.loads((ROOT/'logs/documentation-original-current-refusal.stdout').read_bytes())
if r['exit_code']!=1 or document!={'passed':False,'reason':'inventory_transition'}:raise ValueError('unexpected documentation refusal')
save(ROOT/'OLD_CONTRACTS.json',{'passed':True,'pilot_positive_pin':pin,'pilot_current_refusal':body,'documentation_current_refusal':document,'meaning':'Old scopes still reject the composed root; their failure is not relabelled as a passing old guard.'})
print('OLD_CONTRACTS_PASS',flush=True)
