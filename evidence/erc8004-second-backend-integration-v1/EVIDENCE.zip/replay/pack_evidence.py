"""Package executed receipts only after closure; omit generated source copies."""
from run import *
import zipfile

fresh=ROOT/'fresh';repo=ROOT/'repo';inner=fresh/'build/base15/build/documentation-replay'
def obj(p):return json.loads(Path(p).read_bytes())

def collect():
    for marker in ('FRESH_NEW_DONE.json','INHERITED_FINAL.json','VIEW_CONTROLS.json','OLD_CONTRACTS.json'):
        if not obj(ROOT/marker)['passed']:raise ValueError('not closed: '+marker)
    entries={};omissions={}
    def add(path,name):
        raw=path.read_bytes()
        if name in entries:raise ValueError('duplicate archive path '+name)
        entries[name]=raw
    for folder,prefix in [(ROOT/'logs','commands'),(ROOT/'core-audits','core-audits')]:
        for path in sorted(folder.rglob('*')):
            if path.is_file():add(path,prefix+'/'+path.relative_to(folder).as_posix())
    roots=[(fresh/'build/second-backend-integration','current/second-backend'),
           (fresh/'build/inherited','current/inherited'),
           (fresh/'build/base15/build/documentation-refresh','historical/pr15-binding'),
           (inner/'build/inherited','historical/main4b6-replay'),
           (inner/'build/escrow/integration-replay','historical/main4b6-escrow-correct-output'),
           (Path('D:/vca-escrow-1120/build/escrow/ci'),'historical/main4b6-escrow-short-path'),
           (Path('D:/vca-escrow-1120/build/escrow/ci-ready'),'historical/main4b6-escrow-complete-setup')]
    source_suffixes={'.py','.pyc','.pyo','.mjs','.js','.ts','.sol','.vy','.vyi','.rs','.toml'}
    excluded_dirs={'sources','node_modules','cache','artifacts','__pycache__','.git','lib','target','out'}
    for folder,prefix in roots:
        if not folder.is_dir():raise ValueError('missing evidence directory '+str(folder))
        for path in sorted(folder.rglob('*')):
            if not path.is_file():continue
            rel=path.relative_to(folder);name=prefix+'/'+rel.as_posix()
            reason=None
            if set(rel.parts)&excluded_dirs:reason='generated source/dependency/compiler cache'
            elif path.suffix.lower() in source_suffixes or '.py.' in path.name:reason='generated complete source snapshot'
            elif path.name in ('vyper-logo.png','vyper-logo-dark.png'):reason='source-copy image'
            if reason:
                omissions[name]={'path':str(path),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'reason':reason}
            else:add(path,name)
    files=('BUILD.json','MAIN_CI.json','ENVIRONMENT.json','FRESH_NEW_DONE.json','INHERITED_DONE.json','INHERITED_PREPARED.json','VIEW_CONTROLS.json','OLD_CONTRACTS.json','SOURCE_AUDIT.json','EXECUTION_SUMMARY.json','run.py','prepare_runtime.py','fresh_replay.py','prepare_inherited.py','inherited_replay.py','view_controls.py','old_contracts.py','audit_core.py','workflow_audit.mjs','source_audit.py','pack_evidence.py')
    for name in (*files,'REMOTE_READ_ONLY.json','FINAL_REMOTE.json','summarize.py','recover_escrow.py','INHERITED_RESOLVED.json','recover_escrow_short.py','INHERITED_CLOSURE.json','recover_escrow_deps.py','INHERITED_FINAL.json','LONG_PATH_DIAGNOSTIC.json','long_path_diagnostic.py'):add(ROOT/name,'replay/'+name)
    entries['ARCHIVE_OMISSIONS.json']=(json.dumps(omissions,indent=2,sort_keys=True)+'\n').encode()
    manifest={name:{'sha256':sha(raw),'bytes':len(raw)} for name,raw in sorted(entries.items())}
    entries['MANIFEST.json']=(json.dumps({'schema':'veca-second-backend-evidence-archive-v1','files':manifest,'manifest_self_excluded':True},indent=2,sort_keys=True)+'\n').encode()
    out=repo/'evidence/erc8004-second-backend-integration-v1/EVIDENCE.zip'
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(entries.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,raw)
    with zipfile.ZipFile(out) as archive:
        if archive.testzip() is not None or set(archive.namelist())!=set(entries):raise ValueError('archive structure')
        for name,value in manifest.items():
            if sha(archive.read(name))!=value['sha256']:raise ValueError('archive digest '+name)
    result={'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'entries':len(entries),'omitted_files':len(omissions),'uncompressed_bytes':sum(map(len,entries.values()))}
    save(ROOT/'ARCHIVE_CHECK.json',result);print(json.dumps(result));return result
if __name__=='__main__':collect()
