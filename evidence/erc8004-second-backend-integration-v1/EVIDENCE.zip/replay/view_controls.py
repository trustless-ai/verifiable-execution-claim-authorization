from run import *
import shutil, tempfile
fresh=ROOT/'fresh'
sys.path.insert(0,str(fresh/'tools'))
from second_backend_integration import preservation as p
view=fresh/p.VIEW
rows=[]
parent=Path(tempfile.gettempdir()).resolve()
with tempfile.TemporaryDirectory(prefix='veca-view-controls-',dir=parent) as tmp:
    copy=Path(tmp).resolve()
    if copy.parent!=parent or not copy.name.startswith('veca-view-controls-'):raise ValueError('unsafe test copy')
    names=list(p.strict((view/'artifacts.sha256.json').read_bytes())['files'])+['artifacts.sha256.json','.git']
    for name in names:
        target=copy/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(view/name,target)
    positive=p.check_view(copy,fresh)
    def reject(label,name,mutated,reason):
        path=copy/name;before=path.read_bytes() if path.exists() else None
        try:
            if mutated is None:path.unlink()
            else:path.write_bytes(mutated)
            try:p.check_view(copy,fresh)
            except ValueError as e:
                if str(e)!=reason:raise
                # A refusal must not reset the changed tree behind the caller's back.
                untouched=(not path.exists()) if mutated is None else path.read_bytes()==mutated
                if not untouched:raise ValueError('guard reset test copy')
                rows.append({'id':label,'passed':True,'observed_reason':str(e),'no_reset':True})
            else:raise ValueError('bad view admitted')
        finally:
            if before is None:path.unlink(missing_ok=True)
            else:path.write_bytes(before)
        if not p.check_view(copy,fresh)['passed']:raise ValueError('restore failed')
    reject('dirty-view','README.md',b'controlled dirty view\n','view_tree_identity')
    reject('missing-view-file','research/OPEN_PROOF_OBLIGATIONS.md',None,'view_tree_identity')
    reject('added-view-file','unexpected.txt',b'controlled addition\n','view_tree_identity')
    reject('wrong-view-head','.git',('gitdir: '+str(fresh/'.git')+'\n').encode(),'view_head_identity')
    save(ROOT/'VIEW_CONTROLS.json',{'passed':True,'positive':positive,'controls':rows,'core_never_mutated':True,'source_head':p.git(fresh,'rev-parse','HEAD').decode().strip(),'mutation_location':'disposable copy only','independence':'same Codex executor'})
print('VIEW_CONTROLS',len(rows),'PASS',flush=True)
